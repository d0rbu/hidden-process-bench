"""Frozen six-regime predictive-state filter. Standard library only."""
import json,math,sys
from pathlib import Path

def predict_one(history,model):
    history=history[-model['history_limit']:]
    if not history:
        return model['empty_history_probabilities'][:]
    b=model['initial_belief'][:]
    A=model['transition'];L=model['evidence_likelihood'];E=model['profiles']
    for token in history:
        if not isinstance(token,int) or not 0<=token<16:
            raise ValueError('Tokens must be integers in [0,15]')
        r=[sum(b[i]*A[i][j] for i in range(6))*L[j][token] for j in range(6)]
        normalizer=sum(r)
        b=[v/normalizer for v in r]
    q=[sum(b[j]*E[j][v] for j in range(6)) for v in range(16)]
    C=model['output_calibration'];last=history[-1];clock=math.log1p(len(history))/3.0
    logits=[math.log(max(q[v],1e-300))+C[last][v]+C[16][v]+clock*C[17][v] for v in range(16)]
    maximum=max(logits);r=[math.exp(v-maximum) for v in logits];normalizer=sum(r)
    return [v/normalizer for v in r]

def main():
    model=json.loads(Path(__file__).with_name('parameters.json').read_text())
    request=json.load(sys.stdin)
    if request['vocab_size']!=16:
        raise ValueError('This fitted mechanism has vocabulary size 16')
    result=[predict_one(row,model) for row in request['histories']]
    json.dump({'probabilities':result},sys.stdout,separators=(',',':'),allow_nan=False)
    sys.stdout.write('\n')

if __name__=='__main__':main()
