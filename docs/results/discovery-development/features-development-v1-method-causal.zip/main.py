from method.discovery_features import main
main('causal')
