from method.exception_methods import main
main('neurons')
