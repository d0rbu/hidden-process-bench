import sys,json,numpy as np
from pathlib import Path
z=np.load(Path(__file__).with_name("parameters.npz"),allow_pickle=False)
E,A,initial=z["E"],z["A"],z["initial"]
rho,tau=float(z["rho"]),float(z["tau"]); C=z["correction"]
def predict(history):
    belief=initial.copy();last=16
    for token in history:
        last=int(token)
        if not 0<=last<E.shape[1]:raise ValueError("Token outside vocabulary")
        logw=rho*np.log(np.maximum(belief,1e-300))+tau*np.log(np.maximum(E[:,last],1e-300))
        weight=np.exp(logw-logw.max())
        belief=(weight/weight.sum())@A
    logits=np.log(np.maximum(belief@E,1e-300))+C[last]
    probability=np.exp(logits-logits.max())
    return (probability/probability.sum()).tolist()
request=json.load(sys.stdin)
if request["vocab_size"]!=E.shape[1]:raise ValueError("Expected a 16-token vocabulary")
print(json.dumps({"probabilities":[predict(h) for h in request["histories"]]},allow_nan=False))
