# Mechanism
A persistent sequence-level regime selects one small categorical-emitting Markov chain. There are three regimes and 3/3/2 hidden states per regime. The stochastic transition matrix A is block diagonal; E gives each hidden state's distribution over the 16 tokens. Initial belief pi includes both regime and within-regime uncertainty. State labels have no token semantics.

The explanatory generative core is a mixture of hidden Markov chains:
  p(next)=b E; after observing a, b <- normalize(b * E[:,a]) A.
It explains why evidence accumulates about the regime but order still matters within it. This is not a transcription of neural operations.

The executable includes explicitly separated observation corrections:
  b <- normalize(b**rho * E[:,a]**tau) A;
  p(next) <- normalize((b E) * exp(C[last_token])).
C has an additional empty-history row reproducing the common observed prior. rho=0.967261 and tau=1.105269; noninitial C log-RMS is 0.04197. C changes readout, not state updates. These small corrections approximate neural departures from ideal Bayesian filtering; they are NOT asserted to be properties of the unknown physical source. All parameters are frozen. Entire histories are processed, including beyond 24 tokens; no request-level fitting or row interaction occurs.

## Why this structure
Only the supplied 128 sequences and 3072 predictive distributions were used. Seven centered probability directions explain 99.55% of variation, suggesting a small mixture simplex, not proving a latent count. First-order memory is inadequate: strict held-out KL 0.13750 versus 0.19853 for a constant predictor. An eight-state HMM reaches 0.00942. Unrestricted fits discover three almost-disconnected blocks, with initial masses near one third and increasing posterior regime certainty. Their cross-block rates are below 0.01 per state. Block separation is an economical approximation, not established exact truth.

Static mixtures are inadequate: reversed two-token histories have mean prediction L1 difference 0.128 across 39 pairs; the best five-component static model has held-out KL 0.04796. A mixture of three observed Markov chains scores 0.02389. Seven hidden states score 0.01725. Adding hidden states, emission-dependent transitions or separate observation channels gives only small or inconsistent gains. The last comparison explicitly tested three states in every regime and used a one-standard-error parsimony rule. Numerical tables and caveats are in evidence.json, final parameters in fit_details.json.

## Prior knowledge, assumptions and uncertainty
Prior knowledge was generic finite-alphabet Markov models, mixture models, Bayesian filtering, low-rank identification, gradient optimization and shrinkage calibration. No generating family, state count, weights, external data or extra teacher queries were supplied or inferred from external sources.

Assumed: time-homogeneous dynamics, categorical emissions, hidden-state sufficiency and a fixed alphabet. Latent labels are permutation-invariant. The chosen state count is a useful compact realization, not unique identification: a weak additional state in the last regime remains plausible. Exact block separation, rare-token behavior and behavior past the observed 23-token conditioning horizon are uncertain. Power discounting makes the executable's regime belief revisable rather than literally fixing a sampled regime forever. Neural approximation and finite evidence can confound source dynamics with calibration. Sequence-fold comparisons are exploratory after discovery, not untouched test evidence. The final fixed model is refitted on all supplied rows; its training agreement is not a generalization estimate.

## Fitted structure at a glance
The regime prior masses are 0.341, 0.297 and 0.362. Within the first block, the directed cycle 0 -> 2 -> 1 -> 0 has transition probabilities 0.179, 0.391 and 0.476; reverse edges are much smaller. The second block has diagonal probabilities 0.879, 0.826 and 0.584. The final two-state block has switching probabilities 0.119 and 0.138. Persistence is therefore not simply token repetition, and the first block carries directional temporal structure. Top-emission tokens and full small transition blocks are listed in fit_details.json; these labels are descriptive, not imposed token classes.

## Executability
The bundled predictor processes each row independently with frozen parameters. Verification includes all 3072 cached prediction positions, empty histories, row permutations and 4096-token histories. Empty-history predictions reproduce the normalized common teacher vector; tiny raw differences reflect cached floating-point normalization. These verification computations do not fit or alter the predictor.
