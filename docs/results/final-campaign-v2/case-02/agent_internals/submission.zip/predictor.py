import json,math,sys
from pathlib import Path
P=json.loads(Path(__file__).with_name("parameters.json").read_text())
E=P["emissions"]; C=P["transitions"]; INITIAL=P["initial"]; W=P["recognition"]
GROUPS=((0,1),(2,3,4),(5,6,7))
AR=P["regime_power"]; AC=P["state_power"]; BETA=P["readout_power"]
def softmax(values):
 m=max(values); v=[math.exp(x-m) for x in values]; z=math.fsum(v)
 return [x/z for x in v]
def log(x):return math.log(max(x,1e-200))
def predict(history):
 b=INITIAL[:]
 for token in history:
  x=int(token)
  if x==16:continue
  if x<0 or x>=16:raise ValueError("Symbol outside 0..15")
  w=softmax([log(b[i])+W[i][x] for i in range(8)])
  v=[0.0]*8
  for g,c in zip(GROUPS,C):
   for j,k in enumerate(g):v[k]=math.fsum(w[i]*c[h][j] for h,i in enumerate(g))
  masses=[math.fsum(v[i] for i in g) for g in GROUPS]
  r=softmax([AR*log(m) for m in masses])
  for a,g in enumerate(GROUPS):
   conditional=softmax([AC*log(v[i]) for i in g])
   for i,c in zip(g,conditional):b[i]=r[a]*c
 q=[math.fsum(b[i]*E[i][x] for i in range(8)) for x in range(16)]
 return softmax([BETA*log(qx) for qx in q])
def main():
 request=json.load(sys.stdin)
 if request["vocab_size"]!=16:raise ValueError("Expected vocab_size=16")
 print(json.dumps({"probabilities":[predict(h) for h in request["histories"]]}))
if __name__=="__main__":main()
