# Evidence and fitting record
All information came from the supplied challenge and numerical sandbox. The cached dataset has 128 histories, 24 aligned predictions each, vocabulary 16. Rows 0..95 were used for fitting; rows 96..127 were used for model selection. No evaluation histories were available.

Search proceeded from a uniform executable baseline to marginal/Markov models, low-rank observable operators (ranks 4..16), categorical HMMs (4..12 states, multiple initializations), symbol-labelled stochastic automata, recognition filters, and grouped filters. HMMs were initialized by token-likelihood EM and distilled with exact recursive gradients into softmax parameters. Generalizations were initialized from smaller HMMs and optimized by Adam. Finite-difference gradient checks were performed. Approximately 105750 optimizer iterations across 53 nonlinear fits were used; linear baselines and EM initialization were additional. The selected model is one filter, not an ensemble or neural-weight export.

Source-like probes were sampled from a fitted eight-state HMM; other probes were iid-uniform, repeated-symbol, alternating-symbol, and count/suffix-preserving interventions. The final grouped fitting set was 720 histories: 96 cached training histories plus 624 synthetic histories. Selection used 32 cached histories and 160 other source-like synthetic histories. Some exploratory counterfactual metrics include previously fitted probe histories and must not be treated as clean tests.

All full-network execution was through the provided family-neutral helper; no custom neural implementation was made. Cached alignment was verified to maximum absolute error 1.31e-7. Per-instance counts and totals are in execution_accounting.json. No network, remote oracle, evaluator, external corpus, or generating-process hint was used.

Single-module ablation mean KL from intact predictions, on sixteen cached histories:
[["head", 0, 0, 0.007404150161070919], ["head", 0, 1, 0.011432045006507805], ["head", 0, 2, 0.00416094851569417], ["head", 0, 3, 0.0010583887427681648], ["mlp", 0, 0.019846599445181978], ["head", 1, 0, 0.0016987144184128621], ["head", 1, 1, 0.005142508579465922], ["head", 1, 2, 0.0035448264807633975], ["head", 1, 3, 0.0019756983772976845], ["mlp", 1, 0.01762428361400123]]

Controlled final-position distribution changes (TV):
{
  "shuffle": {
    "mean_TV": 0.12496653984512782,
    "median_TV": 0.09265702150265998,
    "max_TV": 0.43383557798579264
  },
  "reverse": {
    "mean_TV": 0.17119854609390422,
    "median_TV": 0.1693554192161893,
    "max_TV": 0.38152708299227645
  },
  "changed_old_prefix_same_last8": {
    "mean_TV": 0.20698711798273575,
    "median_TV": 0.12332842028870492,
    "max_TV": 0.5045456173948627
  }
}

Standalone tests: fresh Python processes without NumPy successfully predict all cached validation prefixes; agreement with the NumPy research implementation is within floating-point precision. Determinism, single-row/batch equivalence, positivity, normalization, and histories of lengths 0,1,24,120,10000 pass. No challenge-file access is needed by the submission.
