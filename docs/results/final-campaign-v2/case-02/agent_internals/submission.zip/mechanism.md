# Three slow regimes, eight fast predictive states

## Prior and discovery
Only generic probability, Bayesian filtering, and model-selection knowledge was assumed. Neither a generating family nor a state count was supplied. Exchangeable sources, finite-order tables, ordinary HMMs, and symbol-labelled stochastic automata were compared. Seven dominant centered probability directions explain 99.555% of observed variance; this suggested, but did not prove, eight predictive mixture states. Repeated HMM fits separated into three persistent groups containing 2, 3, and 3 states.

## Executable account
parameters.json stores categorical readout rows E, three within-regime transition matrices C, an initial joint belief pi, recognition scores W, and three powers. Submitted state labels are reordered: regimes are {0,1}, {2,3,4}, {5,6,7}. All transition and emission rows are normalized. Scores W are centered across states for each token; their common offset is irrelevant.

Start b=pi. The next-symbol distribution is
    q = softmax(beta * log(b E)).
After observing x, apply
    w = softmax(log(b) + W[:,x]); v = w C,
where C denotes the block-diagonal assembly of the three matrices. Let m_g=sum(v_i for i in g). Set
    r = softmax(ar * log(m));
    c_g = softmax(ac * log(v_g)); b_g = r_g * c_g.
The fitted powers are ar=0.975095, ac=1.384001, beta=1.648590. Logs use a numerical floor of 1e-200. This is a fixed, recursive, hierarchical recognition filter: slow evidence accumulation about a regime plus faster switching within it.

The generative core is a mixture of three categorical HMMs. Exact Bayesian filtering is the restricted case W=log(E), ar=ac=beta=1. The neural predictor is better explained by allowing recognition to differ from generation, mild regime forgetting, sharper within-regime beliefs, and output calibration. Those deviations are an explicit approximate-inference account, not evidence for additional physical hidden states. The calibrated readout rows need not equal the original source's emission distributions.

## Evidence and alternatives
Sequence-validation KL(neural || mechanism), in nats per next-token prediction: fitted marginal 0.19853; last-token table 0.13750; two-token table 0.11624; six-state HMM 0.02235; seven-state 0.01548; eight-state 0.00943; twelve-state 0.00837. With additional synthetic training histories, an eight-state recognition filter achieves 0.00782, and the selected hard-block hierarchical filter achieves 0.006949. An independent synthetic validation set gives 0.008034. Its dense-transition alternative gives 0.006945 and 0.008202 respectively: hard blocks are competitive and structurally simpler. These are model-selection validation results, not untouched final tests.

Ordinary HMMs repeatedly have three near-unit transition eigenvalues; larger models split states while preserving this slow grouping. Order interventions reject exchangeability: shuffling and reversal preserve token counts but change final neural distributions by mean total variation 0.125 and 0.171. Changing only the old prefix while retaining the last eight tokens changes predictions by mean TV 0.207, rejecting a suffix-of-eight-only account. Module ablations and further exploratory residual metrics are recorded in evidence.md and validation.json.

## Limits and uncertainties
The 2+3+3 decomposition is a parsimonious predictive explanation, not uniquely identified source recovery. Similar behavior could come from a different hidden-state basis, weakly switching regimes, a higher-order process, or approximate neural context computations. Hard blocks describe the generative core; ar<1 deliberately leaks posterior confidence toward uniformity rather than asserting exact Bayes for a static regime. Recognition scores and powers are phenomenological. Residual position/context effects remain. Synthetic histories sampled from fitted HMMs are useful probes, not independent samples from the unknown source. Data partitions were reused for selection and no private evaluator was consulted.

The predictor uses only Python's standard library and fixed learned parameters, never the supplied neural code or challenge files. It is deterministic and independent per history, with no fitting or request persistence. It accepts arbitrarily long histories by the same recursion; behavior beyond the neural context is an unvalidated stationary extrapolation. Tokens 0..15 are outputs; optional BOS 16 is ignored.
