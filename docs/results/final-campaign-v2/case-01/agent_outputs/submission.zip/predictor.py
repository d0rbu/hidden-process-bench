import json,sys
from pathlib import Path
import numpy as np

def features(history,automata):
    h=[int(a) for a in history[-23:]]
    s=[]
    for t,tok in enumerate(h):
        s=[(a,b,max(c,len(s)-j),d+int(tok in (3,10))) for j,(a,b,c,d) in enumerate(s)]
        if tok in (2,5): s.append((tok,t,0,0))
        elif tok in (3,10) and s: s.pop()
    f=[1.]
    for j in range(3):
        if len(s)>j:
            typ,born,peak,pops=s[-1-j];sgn=1. if typ==2 else -1.;age=len(h)-born
            f.extend([sgn,sgn*np.log(age),sgn*(age-1),sgn*peak,sgn*pops,1.,np.log(age),peak,pops])
        else: f.extend([0.]*9)
    for rule,cap,window in automata:
        stack=[]
        for tok in h[-int(window):]:
            if tok in (2,5):
                stack.append(tok);stack=stack[-int(cap):]
            elif tok in (3,10) and stack:
                want=2 if tok==3 else 5
                if stack[-1]==want or rule=='pop': stack.pop()
                elif rule=='clear': stack=[]
                elif rule=='search':
                    matches=[j for j,a in enumerate(stack) if a==want]
                    if matches: stack=stack[:matches[-1]]
        f.append(0. if not stack else 1. if stack[-1]==2 else -1.)
    return np.array(f)

def emission_features(history,y,mode):
    h=history[-23:];last=-1 if not h else int(h[-1])
    a=[1.,y,y*y,np.log1p(len(h))]
    if mode=='common': a += [float(last==t) for t in (2,3,5,10)]
    elif mode=='all': a += [float(last==t) for t in range(16)]
    return np.array(a)

def predict(history,z):
    if not history: return (z['initial']/z['initial'].sum()).tolist()
    f=features(history,z['automata'])
    y=1./(1.+np.exp(-np.clip(f@z['closer'],-30.,30.)))
    a=emission_features(history,y,str(z['emission_mode']))@z['emission']
    a=np.r_[a,0.];a-=a.max();v=np.exp(a);v/=v.sum()
    p=np.empty(16);p[z['others']]=v[:-1];p[3]=v[-1]*y;p[10]=v[-1]*(1.-y)
    return (p/p.sum()).tolist()

def main():
    z=np.load(Path(__file__).with_name('parameters.npz'),allow_pickle=False)
    d=json.load(sys.stdin)
    if int(d['vocab_size'])!=16: raise ValueError('Expected the observed 16-symbol vocabulary')
    print(json.dumps({'probabilities':[predict(h,z) for h in d['histories']]}))

if __name__=='__main__': main()
