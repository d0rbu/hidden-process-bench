# Typed stack with imperfect retrieval

## Claim and prior
No generating family, hidden-state count, or task-specific grammar was known. Generic finite-memory rules, independent counters, stacks, and regularized regression were candidate priors. The observed dependencies favor **two typed pushes with nested restoration**, not a particular number of hidden neural states. This executable is an explicit memory algorithm plus fixed calibration; it contains no neural operations or neural weights.

## Symbols and principal update
Symbols 2 and 5 behave as typed openers, with respective closing types 3 and 10. The other twelve symbols do not push or pop. A principal stack pops on either closer; empty-stack closes are ignored. Empty memory permits both closing types; remembered 2 favors 3, and remembered 5 favors 10. Opening probabilities stay near 1/6 each; other symbols retain small nonzero probabilities. Wrong closing types also have nonzero probability: this is not a hard parser.

Nested evidence: after prefix [5,2], teacher (P(3),P(10)) is (0.48546,0.00188); after [5,2,3] it is (0.00223,0.54063), restoring the buried 5. Prefix [10,2,5] similarly changes from (0.00145,0.54558) to (0.49520,0.00244) after its closing 10. Reset-on-close cannot explain these restorations. The centered probability matrix has leading singular values 14.488, 0.409, 0.215, 0.195: most variation reallocates mass between closers. This does not prove a one-dimensional hidden generator.

## Exact executable memory
Use the last 23 history symbols, the longest supplied prediction prefix. This is an extrapolation convention, not evidence of an intrinsic 23-token generator horizon. Empty history returns the normalized common observed initial vector.

For each principal-stack frame store (type,birth,peak,closes). Before processing token t, for each surviving frame at bottom-index j update peak=max(peak,stack_length-j), and increment closes if the current token is 3 or 10. Pushes create (type,t,0,0); either closer pops the top frame if any. At prediction time encode each of the top three frames as

    [g, g*log(a), g*(a-1), g*peak, g*closes, 1, log(a), peak, closes]

where g=+1 for type 2, -1 for type 5, and a=current_length-birth. Missing frames give nine zeros. Add an intercept.

Six additional votes expose approximate retrieval. Each independently replays a suffix with (closure rule, maximum stored depth, suffix length):

    (search,3,10), (clear,3,6), (match,4,24),
    (match,uncapped,12), (match,4,8), (match,3,10).

Suffix length 24 is effectively 23 after initial truncation. The uncapped view is encoded as cap=99, which exceeds the retained history. Overflow discards the oldest frame. A matching close always pops. On mismatch, match leaves memory unchanged; clear empties it; search removes the newest compatible opener and everything above it, or does nothing if none exists. A vote is +1 for top type 2, -1 for top type 5, zero if empty. Six votes plus 28 principal features form 34 features f. These are alternative views of the same memory, not six claimed physical stacks or generator states.

## Readout and emission
A fixed ridge-logistic readout gives y=sigmoid(f dot b), the fraction of closing mass allocated to symbol 3. Let n be the retained history length and

    e=[1,y,y*y,log(1+n),I(last=2),I(last=3),I(last=5),I(last=10)].

For each of the fourteen non-closing symbols, a fixed column of B gives log mass relative to total closing mass. Softmax([eB,0]) yields fourteen symbol probabilities and closing mass m. Set P(3)=m*y and P(10)=m*(1-y). There are 34 logistic coefficients, 8*14 emission coefficients and 16 initial probabilities: 162 continuous numbers plus a small rule bank. Parameters are in parameters.npz. Prediction performs no fitting, persistence or batch interaction.

## Selection evidence
Only the supplied 128 sequences of length 24 and their 3072 probability vectors were used. Initial development rows had index modulo four equal to zero. Hard-stack variants fitted state emission means on the remaining rows. Development mean KL(teacher || candidate): full-history unconditional pop 0.0201; depth capacities 1/2/3/4: 0.0461/0.0157/0.0110/0.0168; suffix windows 4/6/8/10/12: 0.0226/0.0145/0.0101/0.0135/0.0180. Independent counters and reset-on-close were worse (overall KL approximately 0.0777 and 0.0444). A single soft reverse-depth retrieval rule achieved 0.00736 development KL but was less accurate than the chosen calibrated structural model.

The final architecture achieved development KL 0.00598 and mean L1 0.0330 before all-data refitting. Retrospective four-fold sequence fits averaged KL 0.00592 and L1 0.03197. One/two/three principal frames gave four-fold KL 0.00612/0.00600/0.00592; three were retained. These folds are not untouched tests: the six retrieval rules were selected using the first split, and development data informed architecture selection. They are agreement diagnostics, not unbiased generalization guarantees. Final coefficients were then refitted on all cached observations with the structure fixed. Logistic fitting minimizes closing-mass-weighted cross entropy; emission fitting uses ridge regression of log(nonclosing probability / closing mass). Both use ridge strength 0.133333, preserving the selected per-row regularization; the intercept is unpenalized. Emission fitting uses observed closing fractions offline, but inference uses only its own predicted fraction. See evidence.json for final in-sample diagnostics and executable tests.

## Uncertainty and alternatives
Nested restoration supports a stack interpretation more strongly than independent counters or last-open/reset memory. It does not uniquely identify the generator. A sufficiently large finite-state or order-23 process could reproduce these observations. Depth-three or eight-token approximations outperform a literal unbounded stack, suggesting imperfect neural retrieval, bounded storage, or a bounded generator; the observations do not distinguish these explanations. The six-rule bank approximates that uncertainty, not a claim that the true generator implements these exact rules.

Mismatched closes are rare and responses are not fully consistent with one exact policy. Other symbols are only structurally inert: they affect age descriptors, and recent common symbols affect emissions. Absolute position and unobserved long-range effects may remain. Prefixes longer than 23 use a suffix and may forget relevant earlier opens. No interventions, weights, traces, new teacher queries or out-of-distribution oracle tests were available. Conclusions concern the supplied predictions, not proof of the original training generator.
