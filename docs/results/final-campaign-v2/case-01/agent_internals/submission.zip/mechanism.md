# Two-type cancellation with noisy bounded recall

## Executable mechanism
The token roles were inferred, not supplied: **2 opens A, 5 opens B; 3 closes A,
10 closes B**. All other tokens are neutral to the symbolic update. Start empty.
An opener appends (type, opening position). A closer removes the most recent
outstanding opener of its own type; if none exists it is a no-op. Emission depends
primarily on the latest surviving opener, or on the empty regime.
For well-nested histories this is ordinary two-type LIFO nesting. Deleting a
matching type below another type is a tentative extension to malformed input,
not a claim about a uniquely identified underlying grammar.

The independent executable approximates imperfect neural recall as follows:
1. Keep at most the last 24 history tokens. Replay each suffix of lengths 1..24
   from empty and record its top type (empty, A, B).
2. Let a,b be the 24 indicator vectors for suffix top A/B, and
   p=min(history length,23)/24. The first 98 features are [1,a,b,p*a,p*b,p].
3. Replay the full retained history. Let nA,nB be outstanding counts, top flags
   IA,IB, and age be current length minus the latest surviving opening position
   (zero if empty). Append these ten features divided by six:
   [nA,nB,min(nA,6),min(nB,6),IA*nA,IB*nB,IA*nB,IB*nA,IA*age,IB*age].
4. A fixed 108-coefficient linear score followed by a sigmoid estimates the
   close-type coordinate u, trained against teacher p(3)/(p(3)+p(10)). Clip the
   score to [-30,30]. A fixed 7-by-16 matrix maps
   [1,u,u^2,u^3,p,p*u,p*u^2] to emissions. Floor at 1e-7 and normalize.

Thus the substantive structure is typed cancellation/nesting; the small signed
readout calibrates recall and age errors. There are three emission regimes, not
an assumed three-state hidden Markov chain. The outstanding opener list carries
memory. Neither neural tensors nor neural operations appear in the predictor.
The 220 fitted scalars are in parameters.npz; memory.py defines all transitions.
Longer histories use exactly their last 24 tokens and capped position. This is a
chosen bounded-memory extrapolation, not evidence for unbounded-stack accuracy.

## Evidence
* Near-empty cached predictions assign roughly (.166,.163,.257,.269) to tokens
  (2,5,3,10). An A opener shifts close mass to 3 (~.49 versus .002 for 10);
  a B opener shifts it to 10 (~.54 versus .002 for 3). Most remaining mass stays
  on the two openers and diffuse neutral tokens.
* Retrieval is not merely recent-opener memory: [2,5,10] restores A, giving
  (p3,p10)=(.490,.003); [5,2,3] restores B, giving (.002,.541).
  [2,5,10,3] returns approximately empty (.256,.276).
* On cached rows, state-conditioned mean emissions yield KL 0.01926 for strict
  matched LIFO, 0.01719 for type-specific cancellation, 0.02018 for any-pop,
  0.04440 for last-bracket memory, 0.12939 for last-opener memory, and 0.09576
  for count-majority. These are in-sample structural comparisons, not test scores.
* Crossed [2,5,3,10] is approximately empty at early positions, favoring
  type-specific cancellation off support. This result changes under position
  shifts, so no exact mismatch rule is established.
* Forgetting is real and asymmetric: an initial 5 becomes ambiguous after about
  7-10 neutral tokens, while a later-positioned 5 is often preserved. An initial
  2 survives longer. Exact stack-only emissions therefore miss systematic errors.
* Removing layer-0/head-0 causes KL .0624 on 32 cached sequences; other single
  heads cause .0006-.0080. Removing MLP0/MLP1 causes .0861/.0677.
  Held-out linear top-type probes improve from R2 (.726,.799) after block0 to
  (.897,.959) after block1. These interventions support distributed approximate
  memory/retrieval, not a literal exact stack implemented by one neural head.
* Fresh validation used 768 independently generated sequences, without refitting.
  Final mean teacher-to-predictor KL is 0.011418 nats: typed-natural 0.005508,
  LIFO-natural 0.006035, bracket-rich 0.025354, neutral-rich 0.020070.
  The simpler positive suffix-mixture baseline gives .012308 overall.
  The final cached-row fit is 0.005674 nats. No private/evaluation scores were used.

## Prior, uncertainty, alternatives
Prior knowledge: general familiarity with Markov, hidden-state, counter, stack,
and stochastic sequence models, and standard numerical fitting; no supplied
mechanism family, token roles, or latent-state count. The four special tokens,
two types, and three emission regimes were selected from the supplied evidence.

The best-supported claim is noisy two-type nesting/cancellation. A strict Dyck
process, independent typed counters plus recency, or a finite-state approximation
can agree on ordinary short histories. The evidence does not identify an exact
unbounded process, establish mismatch semantics, or separate every neural error
from generating-process noise. Fixed-capacity and leaky-mass models were tested;
leaky refinements have similar validation accuracy but add complexity. The
selected count/age model was retained unchanged after fresh validation.

Rare malformed or neutral-rich histories can produce a confident wrong type;
mean agreement does not establish exact equivalence. Neutral symbols are assumed
interchangeable for symbolic updates; their neural idiosyncrasies are not modeled.
The calibrated emission curve and prefix-position effects are approximations,
not a proposed physical law of the original generator.
