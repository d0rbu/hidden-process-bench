"""Deterministic typed-cancellation memories; no learned hidden-state transition."""
import numpy as np

def symbolic(h):
    outstanding=[]
    for t,x in enumerate(h):
        if x in (2,5):
            outstanding.append((1 if x==2 else 2,t))
        elif x in (3,10):
            a=1 if x==3 else 2
            for j in range(len(outstanding)-1,-1,-1):
                if outstanding[j][0]==a:
                    outstanding.pop(j)
                    break
    return outstanding

def features(history):
    h=history[-24:]
    p=min(len(h),23)/24.
    tops=[]
    for w in range(1,25):
        s=symbolic(h[-w:])
        tops.append(s[-1][0] if s else 0)
    tops=np.asarray(tops)
    base=np.r_[tops==1,tops==2].astype(float)
    s=symbolic(h)
    na=sum(a==1 for a,t in s)
    nb=sum(a==2 for a,t in s)
    top=s[-1][0] if s else 0
    age=len(h)-s[-1][1] if s else 0
    counts=np.array([na,nb,min(na,6),min(nb,6),
        (top==1)*na,(top==2)*nb,(top==1)*nb,(top==2)*na,
        (top==1)*age,(top==2)*age],dtype=float)/6.
    return np.r_[1.,base,p*base,p,counts]

def emission_features(u,p):
    return np.array([1.,u,u*u,u*u*u,p,p*u,p*u*u])
