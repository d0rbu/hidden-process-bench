"""Frozen independent sequence predictor: JSON stdin -> JSON stdout."""
import json,sys
from pathlib import Path
import numpy as np
from memory import features,emission_features

with np.load(Path(__file__).with_name("parameters.npz")) as data:
    B=data["coefficients"].copy()
    C=data["emission_curve"].copy()

def predict(history):
    h=[int(x) for x in history]
    z=float(np.clip(features(h)@B,-30.,30.))
    u=1./(1.+np.exp(-z))
    p=min(len(h),23)/24.
    q=np.maximum(emission_features(u,p)@C,1e-7)
    return q/q.sum()

def main():
    request=json.load(sys.stdin)
    v=int(request["vocab_size"])
    answer=[]
    for h in request["histories"]:
        q=predict(h)
        if v!=16:
            q=np.r_[q,np.full(max(0,v-16),1e-10)][:v]
            q=q/q.sum()
        answer.append(q.tolist())
    print(json.dumps({"probabilities":answer}))

if __name__=="__main__":
    main()
