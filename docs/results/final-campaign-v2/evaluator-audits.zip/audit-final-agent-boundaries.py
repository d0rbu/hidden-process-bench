"""Read public plans and synthetic capture requests; never actor actions or truth."""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from hidden_process_bench.agent_preflight import audit_request
from hidden_process_bench.challenge import INSTRUCTIONS
from hidden_process_bench.submissions import file_manifest

REPO = Path('/home/d0rb/Documents/Github/hidden-process-bench')
ROOT = REPO / 'outputs/final-campaign-v2'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--require-complete', action='store_true')
args = parser.parse_args()
assert not args.out.exists()
protocol = read(ROOT / 'protocol.json')
plans = sorted(ROOT.glob('*/agent_*/plan.json'))
if args.require_complete:
    registration = read(ROOT / 'registration.json')
    assert len(registration['trials']) == 48
    assert registration['all_48_finished_before_any_private_final_scoring']
    assert len(plans) == 12
source = {key: value for key, value in protocol['source_sha256'].items() if key.endswith('.py')}
rows = []
for plan_file in plans:
    plan = read(plan_file)
    trial = plan_file.parent
    method = trial.name
    case = trial.parent.name
    access = method.removeprefix('agent_')
    for key in ('prompt', 'budget', 'binary_sha256', 'catalog_sha256'):
        assert plan[key] == protocol['agent'][key], (case, method, key)
    assert plan['agent_protocol_version'] == protocol['agent']['protocol_version']
    assert plan['oracle_feedback'] is False
    assert plan['method_sha256'] == source
    assert file_manifest(trial / 'method-source') == source
    assert sha(trial / 'catalog.json') == plan['catalog_sha256']
    assert file_manifest(trial / 'challenge', max_bytes=64_000_000) == plan['challenge_sha256']
    public = REPO / 'outputs/private-final-suite-v2/public' / case / access
    assert file_manifest(public, max_bytes=64_000_000) == plan['challenge_sha256']
    assert (public / 'instructions.txt').read_text() == INSTRUCTIONS
    metadata = read(public / 'challenge.json')
    assert set(metadata) == {'schema_version', 'access', 'architecture', 'neural_operations', 'cached_observation_budget', 'additional_teacher_queries', 'offline_execution_accounting'}
    assert metadata['schema_version'] == 1 and metadata['access'] == access
    assert metadata['architecture'] == {'vocab': 16, 'context': 24, 'width': 64, 'heads': 4, 'layers': 2}
    expected_files = {'challenge.json', 'instructions.txt', 'observations.npz'}
    if access == 'internals':
        expected_files.add('weights.npz')
    assert {path.name for path in public.iterdir()} == expected_files
    with np.load(public / 'observations.npz', allow_pickle=False) as arrays:
        expected_arrays = {'tokens', 'probabilities'} | ({'activations'} if access == 'internals' else set())
        assert set(arrays.files) == expected_arrays
        assert arrays['tokens'].shape == (128, 24)
        assert arrays['probabilities'].shape == (128, 24, 16)
        if access == 'internals':
            assert arrays['activations'].shape == (128, 24, 64)
    preflight_path = trial / 'preflight/preflight.json'
    passed = preflight_path.exists()
    captures = sorted((trial / 'preflight').glob('request-*.json'))
    if passed:
        preflight = read(preflight_path)
        assert preflight['status'] == 'passed'
        assert preflight['real_discovery_model_calls'] == 0
        for key in ('binary_sha256', 'catalog_sha256'):
            assert preflight[key] == plan[key]
        assert len(captures) == preflight['requests'] >= 1
        for request in captures:
            audit_request(read(request), plan['prompt'])
    elif args.require_complete:
        terminal = read(trial / 'trial.json')
        assert terminal['status'] == 'failed' and terminal['failed_during'] == 'preflight'
        assert terminal['model_calls_attempted'] == 0
    rows.append({'id': case, 'method': method, 'plan_sha256': sha(plan_file),
                 'exact_frozen_prompt_budget_binary_catalog_and_sources': True,
                 'challenge_hashes_match_neutral_public_packet': True,
                 'neutral_metadata_and_array_field_allowlists_verified': True,
                 'captured_context_audit_passed': passed,
                 'synthetic_capture_sha256': {path.name: sha(path) for path in captures}})
receipt = {'verified_at': datetime.now(timezone.utc).isoformat(),
           'protocol_sha256': sha(ROOT / 'protocol.json'),
           'started_agent_trials': len(rows), 'complete_terminal_registry_required': args.require_complete,
           'private_test_truth_or_scores_opened': False, 'method_hypotheses_or_actions_opened': False,
           'trials': rows}
args.out.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'audited': len(rows), 'out': str(args.out)}))
