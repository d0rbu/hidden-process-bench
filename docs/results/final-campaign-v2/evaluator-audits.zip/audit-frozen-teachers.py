"""Post-registration recomputation of actual teacher qualification artifacts.

This is evaluator-only verification, never an extraction helper. It refuses to
open private plans/processes/arrays until the entire method roster has terminated.
"""
import argparse
import hashlib
import json
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

from hidden_process_bench.experiment import predictions
from hidden_process_bench.generators import load_process
from hidden_process_bench.metrics import optimality, sequence_kl
from hidden_process_bench.model import TinyTransformer
from hidden_process_bench.mixed_suite import SuiteConfig, _prepare_process
from hidden_process_bench.submissions import file_manifest

REPO = Path('/home/d0rb/Documents/Github/hidden-process-bench')


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--campaign', choices=['dev1', 'dev2', 'final2'], required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    final = args.campaign == 'final2'
    legacy = args.campaign == 'dev1'
    root = REPO / 'outputs' / ('final-campaign-v2' if final else 'agent-development-v1' if legacy else 'agent-development-v2')
    suite = REPO / 'outputs' / ('private-final-suite-v2' if final else 'private-mixed-pilot-v2')
    # Nothing below this barrier runs against private data before all trials end.
    registration = read(root / 'registration.json')
    assert len(registration['trials']) == (48 if final else 5 if legacy else 10)
    assert registration['all_48_finished_before_any_private_final_scoring' if final else 'all_five_finished_before_private_scoring' if legacy else 'all_ten_finished_before_private_scoring']
    protocol = read(root / ('protocol.json' if final else 'plan.json'))
    source_hashes = protocol['source_sha256' if final else 'method_sha256']
    verified_sources = {}
    source_folder = Path(sys.modules[TinyTransformer.__module__].__file__).resolve().parent
    for name in ('generators.py', 'process.py', 'model.py', 'metrics.py', 'experiment.py', 'mixed_suite.py', 'sampling.py'):
        digest = sha(source_folder / name)
        assert digest == source_hashes[name], name
        verified_sources[name] = digest
    args.out.mkdir(parents=True, exist_ok=False)
    plan = read(suite / 'private/plan.json')
    config = plan['config']
    preparation = read(suite / 'private/preparation.json')
    assert preparation['plan_sha256'] == sha(suite / 'private/plan.json')
    torch.set_num_threads(2)
    ids = sorted({x['id'] for x in registration['trials']})
    assert len(ids) == (6 if final else 5)
    all_seeds = [value for case in plan['cases'] for value in case['seeds'].values()]
    assert len(all_seeds) == len(set(all_seeds))
    records = []
    for case_id in ids:
        case = next(x for x in plan['cases'] if x['id'] == case_id)
        private = suite / 'private' / case_id
        training = private / 'training'
        report = read(training / 'report.json')
        assert report['checkpoint_qualified'] and report['status'] == 'qualified'
        assert report['plan_sha256'] == preparation['plan_sha256']
        assert report['process_sha256'] == sha(private / 'process.json')
        assert report['checkpoint_sha256'] == sha(training / 'checkpoint.pt')
        assert read(private / 'screening.json')['accepted']
        process = load_process(private / 'process.json')
        generation = args.out / case_id / 'regenerated-task'
        generation.mkdir(parents=True)
        regenerated, screen = _prepare_process(case['family'], SuiteConfig(**config), case['seeds'], generation)
        assert regenerated.specification() == read(private / 'process.json')
        assert json.loads(json.dumps(screen)) == read(private / 'screening.json')
        sampling_sha = None
        if (private / 'sampling.jsonl').exists():
            sampling_sha = sha(private / 'sampling.jsonl')
            assert sha(generation / 'sampling.jsonl') == sampling_sha
        model = TinyTransformer.load(training / 'checkpoint.pt')
        architecture = asdict(model.config)
        assert architecture == {'vocab': config['vocab'], 'context': config['length'], 'width': config['width'], 'heads': config['heads'], 'layers': config['layers']}
        assert report['training_tokens'] == report['steps'] * config['batch_size'] * config['length']
        assert report['model_parameters'] == sum(x.numel() for x in model.parameters())
        stats = {}
        with np.load(training / 'qualification.npz', allow_pickle=False) as arrays:
            for split in ('validation', 'test'):
                tokens, groups = process.sample(np.random.default_rng(case['seeds'][split]), config['eval_sequences'], config['length'])
                np.testing.assert_array_equal(tokens, arrays[split + '_tokens'])
                np.testing.assert_array_equal(groups, arrays[split + '_groups'])
                oracle = process.probabilities(tokens)[:, :-1]
                predicted, _ = predictions(model, tokens)
                np.testing.assert_array_equal(oracle, arrays[split + '_oracle'])
                np.testing.assert_array_equal(predicted, arrays[split + '_teacher'])
                threshold = config['max_kl'] * (config.get('validation_margin', 1) if split == 'validation' else 1)
                actual = optimality(oracle, predicted, groups, process.groups, threshold)
                assert actual == report[split], (case_id, split)
                assert actual['qualified']
                stats[split + '_kl'] = sequence_kl(oracle, predicted)
                stats[split + '_groups'] = groups
        paired = {}
        for access in ('outputs', 'weights', 'internals'):
            public = suite / 'public' / case_id / access
            assert file_manifest(public, max_bytes=64_000_000) == report['public_challenge_sha256'][access]
            if access != 'weights':
                with np.load(public / 'observations.npz', allow_pickle=False) as obs:
                    paired[access] = {key: obs[key].copy() for key in ('tokens', 'probabilities')}
        for key in ('tokens', 'probabilities'):
            np.testing.assert_array_equal(paired['outputs'][key], paired['internals'][key])
        # Scoring artifacts remain bound to an independently sampled generating stream.
        for label, length, seed_name in [('heldout', config['length'], 'scoring'), ('long', config['long_length'], 'long_scoring')]:
            with np.load(training / (label + '.npz'), allow_pickle=False) as arrays:
                tokens, groups = process.sample(np.random.default_rng(case['seeds'][seed_name]), config['score_sequences'], length)
                np.testing.assert_array_equal(tokens, arrays['tokens'])
                np.testing.assert_array_equal(groups, np.load(training / (label + '-groups.npy'), allow_pickle=False))
                np.testing.assert_array_equal(process.probabilities(tokens)[:, :-1], arrays['oracle'])
                if label == 'heldout':
                    np.testing.assert_array_equal(predictions(model, tokens)[0], arrays['teacher'])
                else:
                    assert 'teacher' not in arrays
        folder = args.out / case_id
        folder.mkdir(exist_ok=True)
        np.savez_compressed(folder / 'qualification-stats.npz', **stats)
        record = {'id': case_id, 'checkpoint_qualified': True, 'architecture': architecture,
                  'task_and_every_screening_candidate_recomputed_from_original_seeds': True,
                  'screening_sha256': sha(private / 'screening.json'), 'sampling_audit_sha256': sampling_sha,
                  'checkpoint_sha256': report['checkpoint_sha256'], 'process_sha256': report['process_sha256'],
                  'teacher_report_sha256': sha(training / 'report.json'),
                  'qualification_arrays_sha256': sha(training / 'qualification.npz'),
                  'qualification_stats_sha256': sha(folder / 'qualification-stats.npz'),
                  'validation_threshold': report['validation']['max_kl'], 'test_threshold': report['test']['max_kl'],
                  'all_qualification_samples_groups_oracles_teacher_predictions_recomputed_exactly': True,
                  'public_packet_hashes_verified_and_paired_observations_equal': True,
                  'heldout_and_long_samples_groups_oracles_recomputed_exactly': True,
                  'heldout_teacher_predictions_recomputed_exactly': True,
                  'long_teacher_absent': True}
        records.append(record)
        write(args.out / 'progress.json', {'cases': records})
        print(json.dumps({'id': case_id, 'teacher_audit': 'passed'}), flush=True)
    write(args.out / 'report.json', {'registration_sha256': sha(root / 'registration.json'),
          'source_hashes_verified': verified_sources, 'all_seeds_distinct_within_whole_suite': True,
          'audited_case_count': len(records), 'all_audits_passed': True, 'cases': records})


if __name__ == '__main__':
    main()
