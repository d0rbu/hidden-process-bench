"""Publish registered development/final evidence only after terminal roster + review.

Operational helper, not a method. Never imports a frozen run's modules or changes
its sources. Run using the current locked project after supplying a review keyed
by opaque ID/method and bound to each submission receipt.
"""
import argparse
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

import numpy as np

from hidden_process_bench.submissions import FrozenSubmission, file_manifest, verify_submission

REPO = Path('/home/d0rb/Documents/Github/hidden-process-bench')


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def archive(path, folder, files=None):
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as out:
        sources = (folder / name for name in sorted(files)) if files is not None else sorted(folder.rglob('*'))
        for source in sources:
            if not source.is_file() or '__pycache__' in source.parts:
                continue
            name = str(source.relative_to(folder))
            if files is not None and name not in files:
                continue
            entry = zipfile.ZipInfo(name, (2026, 10, 27, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            out.writestr(entry, source.read_bytes())


def preserve_array(source, directory, stem):
    """Preserve exact original NPZ bytes, with parts below the local file-size gate."""
    raw = source.read_bytes()
    parts = []
    for offset in range(0, len(raw), 900_000):
        name = stem + f'.npz.part-{len(parts):02}'
        (directory / name).write_bytes(raw[offset:offset + 900_000])
        parts.append(name)
    assert b''.join((directory / name).read_bytes() for name in parts) == raw
    return {'sha256': sha(source), 'bytes': len(raw), 'parts': parts}


def terminal_usage(trial):
    usage = {}
    complete = 0
    for path in sorted(trial.glob('step-*/model/events.jsonl')):
        for line in path.read_text().splitlines():
            event = json.loads(line)
            if event.get('type') == 'turn.completed':
                complete += 1
                for key, value in event.get('usage', {}).items():
                    if isinstance(value, (int, float)):
                        usage[key] = usage.get(key, 0) + value
    return {'completed_model_calls': complete, 'completed_calls_usage': usage,
            'token_usage_scope': 'Terminal turn.completed usage only; any timed-out calls are excluded. This is a lower bound.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--campaign', choices=['dev2', 'final2'], required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--review', type=Path, required=True)
    parser.add_argument('--teacher-audit', type=Path, required=True)
    args = parser.parse_args()
    final = args.campaign == 'final2'
    root = REPO / 'outputs' / ('final-campaign-v2' if final else 'agent-development-v2')
    suite = REPO / 'outputs' / ('private-final-suite-v2' if final else 'private-mixed-pilot-v2')
    # Do not open any private process or scoring data before these assertions.
    registration = read(root / 'registration.json')
    expected = 48 if final else 10
    assert len(registration['trials']) == expected
    assert registration['all_48_finished_before_any_private_final_scoring' if final else 'all_ten_finished_before_private_scoring']
    report = read(root / 'report.json')
    rows = report['trials' if final else 'cases']
    assert len(rows) == expected
    for row in rows:
        row['method'] = row.get('method', 'agent_' + row['access'])
    assert len({(x['id'], x['method']) for x in rows}) == expected
    reviews = read(args.review)
    assert reviews['registration_sha256'] == sha(root / 'registration.json')
    assert set(reviews['trials']) == {x['id'] + '/' + x['method'] for x in rows}
    teacher_audit = read(args.teacher_audit / 'report.json')
    assert teacher_audit['all_audits_passed']
    assert teacher_audit['registration_sha256'] == sha(root / 'registration.json')
    assert {x['id'] for x in teacher_audit['cases']} == {x['id'] for x in rows}
    if final:
        boundary = read(root / 'complete-agent-boundary-audit.json')
        assert boundary['complete_terminal_registry_required']
        assert boundary['started_agent_trials'] == len(boundary['trials']) == 12
        assert boundary['protocol_sha256'] == sha(root / 'protocol.json')
        assert reviews['diagnostics_sha256'] == sha(root / 'structural-diagnostics/report.json')
        assert reviews['criteria_sha256'] == sha(REPO / 'outputs/structure-review-criteria-20261027.md')
        assert reviews['linear_parameter_audit_sha256'] == sha(root / 'linear-parameter-audit.json')
    args.out.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(args.teacher_audit / 'report.json', args.out / 'qualification-audit.json')
    shutil.copyfile(args.review, args.out / 'structural-review.json')
    if final:
        archive(args.out / 'evaluator-audits.zip', REPO / 'outputs', {'audit-frozen-teachers.py', 'audit-final-agent-boundaries.py', 'publish-frozen-campaign.py', 'final-structural-diagnostics.py'})
        shutil.copyfile(root / 'structural-diagnostics/report.json', args.out / 'structural-diagnostics.json')
        shutil.copyfile(root / 'linear-parameter-audit.json', args.out / 'linear-parameter-audit.json')
        shutil.copyfile(REPO / 'outputs/structure-review-criteria-20261027.md', args.out / 'structure-review-criteria.md')
        mapping = {case: f'case-{index + 1:02}' for index, case in enumerate(sorted({x['id'] for x in rows}))}
    else:
        mapping = read(REPO / 'outputs/agent-development-v1/publication-map.json')
    plan = read(root / ('protocol.json' if final else 'plan.json'))
    source = root / ('src/hidden_process_bench' if final else 'method-source/hidden_process_bench')
    source_hashes = {name: digest for name, digest in plan['source_sha256' if final else 'method_sha256'].items() if '__pycache__' not in Path(name).parts}
    assert all(sha(source / name) == digest for name, digest in source_hashes.items())
    archive(args.out / 'runtime-source.zip', source, source_hashes)
    shutil.copyfile(root / ('protocol.json' if final else 'plan.json'), args.out / 'frozen-protocol.json')
    if final:
        for method in plan['methods']:
            if method['bundle'] is not None:
                assert file_manifest(root / method['bundle']) == plan['method_sha256'][method['name']]
                archive(args.out / ('method-' + method['name'] + '.zip'), root / method['bundle'])
    shutil.copyfile(root / 'registration.json', args.out / 'registration.json')
    shutil.copyfile(root / 'scoring-plan.json', args.out / 'scoring-plan.json')
    write(args.out / 'case-mapping.json', mapping)
    if final:
        for name in ('execution-plan.json', 'suite-binding.json', 'execution-cache-audit.json', 'agent-admission.json'):
            shutil.copyfile(root / name, args.out / name)
        for optional in ('transient-auth-incident.json', 'external-admission-hold.json', 'external-admission-resume.json', 'complete-agent-boundary-audit.json', 'pre-registration-late-boundary-audit.json', 'pre-registration-late-submission-integrity-audit.json'):
            if (root / optional).exists():
                shutil.copyfile(root / optional, args.out / optional)
        if (root / 'auth-returned-preflight/preflight.json').exists():
            shutil.copyfile(root / 'auth-returned-preflight/preflight.json', args.out / 'auth-returned-preflight.json')
        shutil.copyfile(REPO / 'outputs/final-public-input-audit-20261027.json', args.out / 'public-input-audit.json')
        archive(args.out / 'orchestration.zip', root, {'prepare-train.py', 'run-frozen.py'})
    else:
        archive(args.out / 'orchestration.zip', root, {'run.py'})
    outputs = []
    for row in sorted(rows, key=lambda x: (mapping[x['id']], x['method'])):
        case = mapping[row['id']]
        method = row['method']
        trial = root / row['id'] / (method if final else row['access'])
        target = args.out / case / method
        target.mkdir(parents=True)
        receipt = row['submission_receipt_sha256'] if final else row['receipt_sha256']
        review = reviews['trials'][row['id'] + '/' + method]
        assert review['submission_receipt_sha256'] == receipt
        result = {'case': case, 'method': method, 'access': row['access'],
                  'family_after_registration': row['family_after_registration' if final else 'family'],
                  'status': row['status'] if final else row['trial']['status'],
                  'submission_receipt_sha256': receipt,
                  'heldout': row.get('heldout'), 'long': row.get('long'),
                  'structural_assessment': review['assessment']}
        if method.startswith('agent_'):
            agent_trial = row['trial']
            result['agent_trial'] = agent_trial
            result.update(terminal_usage(trial))
            shutil.copyfile(trial / 'plan.json', target / 'agent-plan.json')
            preflight = trial / 'preflight'
            if (preflight / 'preflight.json').exists():
                shutil.copyfile(preflight / 'preflight.json', target / 'preflight.json')
            for capture in sorted(preflight.glob('request-*.json')):
                shutil.copyfile(capture, target / ('preflight-' + capture.name))
            actions = read(trial / 'history.json')['actions'] if (trial / 'history.json').exists() else []
            write(target / 'actions.json', actions)
            preflight_stderr = trial / 'preflight/client/stderr.txt'
            if preflight_stderr.exists():
                shutil.copyfile(preflight_stderr, target / 'preflight-stderr.txt')
            trajectory = []
            for step in trial.glob('step-*'):
                for relative in ('action.json', 'analysis/stdout.txt', 'analysis/stderr.txt', 'model/prompt.txt', 'model/stderr.txt', 'model/events.jsonl'):
                    if (step / relative).is_file():
                        trajectory.append(str((step / relative).relative_to(trial)))
            archive(target / 'trajectory.zip', trial, trajectory)
        if final and not method.startswith('agent_'):
            extraction = trial / 'extraction'
            if (extraction / 'extraction.json').exists():
                shutil.copyfile(extraction / 'extraction.json', target / 'extraction-result.json')
            for stream in ('stdout.txt', 'stderr.txt'):
                original = extraction / 'execution' / stream
                if original.exists():
                    shutil.copyfile(original, target / ('extraction-' + stream))
        if receipt is not None:
            submission = trial / ('extraction/submission' if not method.startswith('agent_') else 'submission')
            frozen = FrozenSubmission(submission, receipt)
            verify_submission(frozen)
            archive(target / 'submission.zip', submission)
            result['submission_metadata'] = read(submission / 'submission.json')
            if (submission / 'selection.json').exists():
                result['selection'] = read(submission / 'selection.json')
            for split in ('heldout', 'long'):
                score = row[split]
                assert score['submission_receipt_sha256'] == receipt
                write(target / (split + '.json'), score)
                if score['status'] != 'scored':
                    continue
                result[split + '_max_total_variation'] = row[split + '_max_total_variation']
                if final:
                    arrays = preserve_array(trial / ('score-' + split) / 'predictions.npz', target, split + '-predictions')
                    write(target / (split + '-arrays.json'), arrays)
                    inputs = target.parent / (split + '-inputs.json')
                    if inputs.exists():
                        assert read(inputs)['sha256'] == score['private_inputs_sha256']
                    else:
                        record = preserve_array(trial / ('score-' + split) / 'private-inputs.npz', target.parent, split + '-inputs')
                        assert record['sha256'] == score['private_inputs_sha256']
                        write(inputs, record)
                # The witness is evaluated from preserved scorer inputs, never refit.
                with np.load(trial / ('score-' + split) / 'private-inputs.npz', allow_pickle=False) as private:
                    with np.load(trial / ('score-' + split) / 'predictions.npz', allow_pickle=False) as prediction:
                        differences = np.abs(prediction['probabilities'] - private['oracle']).sum(axis=-1) / 2
                        sequence, position = np.unravel_index(differences.argmax(), differences.shape)
                        write(target / (split + '-witness.json'), {
                            'history': private['tokens'][sequence, :position].tolist(),
                            'oracle_probabilities': private['oracle'][sequence, position].tolist(),
                            'candidate_probabilities': prediction['probabilities'][sequence, position].tolist(),
                            'total_variation': float(differences[sequence, position]),
                            'selected_after_registration': True})
        outputs.append(result)
    quality = read(suite / 'private/training-summary.json')
    for original, published in (('plan.json', 'task-plan.json'), ('preparation.json', 'task-preparation.json'), ('training-summary.json', 'teacher-training-summary.json')):
        shutil.copyfile(suite / 'private' / original, args.out / published)
    teacher_rows = []
    for case in sorted({x['id'] for x in rows}):
        teacher = read(suite / 'private' / case / 'training/report.json')
        directory = args.out / mapping[case]
        shutil.copyfile(suite / 'private' / case / 'screening.json', directory / 'screening.json')
        for optional in ('sampling.jsonl', 'preparation.json'):
            original = suite / 'private' / case / optional
            if original.exists():
                shutil.copyfile(original, directory / optional)
        for optional in ('trace.jsonl', 'provenance.json'):
            original = suite / 'private' / case / 'training' / optional
            if original.exists():
                shutil.copyfile(original, directory / optional)
        shutil.copyfile(suite / 'private' / case / 'training/report.json', directory / 'teacher.json')
        shutil.copyfile(suite / 'private' / case / 'process.json', directory / 'source-process.json')
        if final:
            shutil.copytree(suite / 'public' / case, directory / 'public')
            shutil.copyfile(suite / 'private' / case / 'training/checkpoint.pt', directory / 'teacher-checkpoint.pt')
        audited = next(x for x in teacher_audit['cases'] if x['id'] == case)
        stats = args.teacher_audit / case / 'qualification-stats.npz'
        assert sha(stats) == audited['qualification_stats_sha256']
        assert sha(directory / 'teacher.json') == audited['teacher_report_sha256']
        shutil.copyfile(stats, directory / 'qualification-stats.npz')
        teacher_rows.append({'case': mapping[case], 'checkpoint_qualified': teacher['checkpoint_qualified'],
                             'teacher_receipt_sha256': sha(directory / 'teacher.json'),
                             'source_process_sha256': sha(directory / 'source-process.json'),
                             'qualification_stats_sha256': sha(directory / 'qualification-stats.npz')})
    summary = {'schema_version': 1, 'evaluation': 'fresh_frozen_campaign' if final else 'paired_agent_development_v2',
               'final_campaign': final, 'process_family_disclosed_to_methods': False,
               'process_order_disclosed_to_methods': False, 'supplied_hmm_fitting_adapter': False,
               'all_submissions_registered_before_any_private_scoring': True,
               'method_sources_fixed_before_task_generation': final,
               'trials': expected, 'cases': outputs, 'teachers': teacher_rows,
               'submitted': sum(x['status'] == 'submitted' for x in outputs),
               'suite_campaign_ready': quality['campaign_ready'],
               'registration_sha256': sha(root / 'registration.json'),
               'private_report_sha256': sha(root / 'report.json'),
               'private_plan_sha256': sha(suite / 'private/plan.json'),
               'structural_review_sha256': sha(args.review), 'runtime_source_sha256': source_hashes,
               'protocol_sha256': sha(root / ('protocol.json' if final else 'plan.json')),
               'independent_structure_recovery_demonstrated': any(x['structural_assessment']['independent_structure_recovery_demonstrated'] for x in outputs),
               'query_comparison': 'Paired cached tokens/probabilities are equal. Internal methods can execute weights; extra forwards, interventions and model actions must be reported. This is not an equal-compute or equal-query causal comparison.'}
    write(args.out / 'summary.json', summary)
    # This is a published receipt dataset, not an executable sandbox bundle.
    # The complete 48-trial dataset exceeds executable file-count limits.
    write(args.out / 'manifest.json', {str(path.relative_to(args.out)): sha(path) for path in sorted(args.out.rglob('*')) if path.is_file()})
    write(root / 'publication-map.json', mapping)
    print(json.dumps({'rows': len(outputs), 'submitted': summary['submitted'], 'out': str(args.out)}))


if __name__ == '__main__':
    main()
