"""Post-registration diagnostics of original programs; no fitting or replacement."""
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np

from hidden_process_bench.discovery import predict_histories
from hidden_process_bench.generators import load_process
from hidden_process_bench.submissions import FrozenSubmission, verify_submission

ROOT = Path('/home/d0rb/Documents/Github/hidden-process-bench/outputs/final-campaign-v2')
SUITE = ROOT.parent / 'private-final-suite-v2/private'
OUT = ROOT / 'structural-diagnostics'


def read(p):
    return json.loads(p.read_text())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    reg = read(ROOT / 'registration.json')
    assert reg['all_48_finished_before_any_private_final_scoring']
    assert len(reg['trials']) == 48
    OUT.mkdir(exist_ok=False)
    rows = []
    for row in reg['trials']:
        path = ROOT / row['path']
        frozen = FrozenSubmission(path, row['submission_receipt_sha256'])
        verify_submission(frozen)
        process = load_process(SUITE / row['id'] / 'process.json')
        spec = process.specification()
        record = {'id': row['id'], 'method': row['method'],
                  'submission_receipt_sha256': frozen.receipt_sha256,
                  'source_process_sha256': sha(SUITE / row['id'] / 'process.json')}
        if not row['method'].startswith('agent_'):
            mechanism = read(path / 'mechanism.json')
            selection = read(path / 'selection.json')
            record.update(predictor_sha256=sha(path / 'predict.py'),
                          state_dimension=mechanism['state_dimension'],
                          family_evidence=mechanism.get('family_evidence', selection.get('structure')))
        elif spec['family'] == 'lag_rule':
            lag = spec['lag']
            permutation = np.array(spec['alphabet'])
            matched = total = 0
            minimum = 1.
            maximum = 0.
            hist = itertools.product(range(16), repeat=lag)
            batch = 0
            while histories := list(itertools.islice(hist, 4096)):
                histories = [list(h) for h in histories]
                q = predict_histories(frozen, histories, 16, OUT / row['id'] / row['method'] / f'exhaustive-{batch:02}')
                expected = permutation[np.asarray(histories)[:, -lag]]
                matched += int((q.argmax(axis=1) == expected).sum())
                total += len(q)
                favored = q[np.arange(len(q)), expected]
                minimum = min(minimum, float(favored.min()))
                maximum = max(maximum, float(favored.max()))
                batch += 1
            record['exhaustive_minimum_length'] = {'history_length': lag, 'histories': total,
                'source_modal_matches': matched, 'modal_probability_min': minimum,
                'modal_probability_max': maximum, 'source_modal_probability':
                spec['strength'] + (1-spec['strength'])/16,
                'scope': 'All histories of exactly this length, not an all-length equivalence certificate.'}
            record['longer_uniform_histories'] = []
            for length in (23, 72):
                histories = np.random.default_rng(2026102700 + length).integers(0, 16, size=(1024, length)).tolist()
                q = predict_histories(frozen, histories, 16, OUT / row['id'] / row['method'] / f'random-{length}')
                expected = permutation[np.asarray(histories)[:, -lag]]
                record['longer_uniform_histories'].append({'length': length, 'histories': len(histories),
                    'source_modal_matches': int((q.argmax(axis=1) == expected).sum())})
        elif spec['family'] == 'stack_rule':
            a,b,ca,cb = spec['alphabet'][:4]
            histories = [[a,b], [a,b,cb], [b,a,ca], [a,b,ca,cb], [a,b,ca]]
            # Different lengths are separate requests, preserving the real interface.
            probes = []
            for index,h in enumerate(histories):
                q = predict_histories(frozen, [h], 16, OUT / row['id'] / row['method'] / f'stack-{index}')[0]
                oracle = process.probabilities(np.array([h], dtype=np.int64))[0,-1]
                probes.append({'history': h, 'candidate': q.tolist(), 'oracle': oracle.tolist(),
                               'total_variation': float(np.abs(q-oracle).sum()/2)})
            record['stack_probes'] = probes
        rows.append(record)
    report = {'registration_sha256': sha(ROOT/'registration.json'),
              'diagnostics_after_all_48_registered': True, 'refitting_or_predictor_substitution': False,
              'trials': rows}
    (OUT/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({'trials': len(rows), 'report': str(OUT/'report.json')}), flush=True)


if __name__ == '__main__':
    main()
