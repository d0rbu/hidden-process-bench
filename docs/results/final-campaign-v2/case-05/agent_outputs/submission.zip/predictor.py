"""Frozen lag-four categorical mechanism; Python standard library only."""
import sys,json,math
from pathlib import Path
PERM=(3,7,13,2,14,6,0,1,5,10,8,12,15,4,11,9)
LAGS=(1,3,7)

def softmax(z):
    top=max(z);q=[math.exp(x-top) for x in z];total=sum(q)
    return [x/total for x in q]

def sum_vectors(table,indices):
    return [sum(table[i][j] for i in indices) for j in range(16)]

def predict(h,p):
    t=len(h)
    if t<4:
        indices=[0,1+t]
        for j,lag in enumerate((1,2,3)):
            if t>=lag:indices.append(5+16*j+h[-lag])
        return softmax(sum_vectors(p['initial_weights'],indices))
    source=h[-4];mode=PERM[source]
    indices=[0,1+source]
    if t<24:indices.append(17+t-4)
    for j,lag in enumerate(LAGS):
        if t>=lag:indices.append(37+16*j+h[-lag])
    confidence=sum(p['mode_weights'][i] for i in indices)
    confidence+=p['mode_source_last'][source][h[-1]]
    confidence+=p['mode_source_lag7'][source][h[-7] if t>=7 else 16]
    logits=sum_vectors(p['off_weights'],indices)
    if t<24:
        confidence+=p['mode_source_position'][source][t-4]
        correction=p['off_source_position'][source][t-4]
        logits=[x+y for x,y in zip(logits,correction)]
    mass=1/(1+math.exp(-max(-40,min(40,confidence))))
    logits[mode]=-1000
    q=[x*(1-mass) for x in softmax(logits)];q[mode]=mass
    return q

def main():
    request=json.load(sys.stdin)
    if request['vocab_size']!=16:raise ValueError('Expected 16 observed symbols')
    with Path(__file__).with_name('parameters.json').open() as file:p=json.load(file)
    probabilities=[]
    for h in request['histories']:
        if any(type(x) is not int or not 0<=x<16 for x in h):
            raise ValueError('Expected observed token IDs 0..15, without BOS')
        probabilities.append(predict(h,p))
    print(json.dumps({'probabilities':probabilities},allow_nan=False))

if __name__=='__main__':main()
