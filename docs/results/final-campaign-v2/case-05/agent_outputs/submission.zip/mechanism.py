"""Parsimonious structural mechanism, without neural calibration."""
import random
PERM=(3,7,13,2,14,6,0,1,5,10,8,12,15,4,11,9)
LAGS=(1,3,7)
def core_probabilities(history):
    if len(history)<4:return [1/16]*16
    p=[.02]*16;p[PERM[history[-4]]]=.70;return p

def sample_sequence(length,seed=0):
    # Four independent phase chains, realized with one four-symbol FIFO.
    rng=random.Random(seed);history=[]
    for t in range(length):
        if t<4 or rng.random()>=.68:token=rng.randrange(16)
        else:token=PERM[history[-4]]
        history.append(token)
    return history
