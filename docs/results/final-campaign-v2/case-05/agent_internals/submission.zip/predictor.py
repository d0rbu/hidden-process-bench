"""Fixed noisy lag-four substitution channel; no teacher or fitting at runtime."""
import sys,json
from pathlib import Path
import numpy as np
with np.load(Path(__file__).with_name("parameters.npz"),allow_pickle=False) as z:
    z={k:z[k].copy() for k in z.files}
eye=np.eye(16)
def softmax(a):
    a=a-a.max();p=np.exp(a);return p/p.sum()
def predict(h):
    t=len(h)
    if not t:return (z["bos"]/z["bos"].sum()).tolist()
    if t<4:
        histogram=np.bincount(h,minlength=16)/t
        f=np.r_[np.eye(4)[t],eye[h[-1]],histogram]
        return softmax(f@z["early"]).tolist()
    s=h[-4];last=h[-1]
    pos=np.eye(20)[t-4] if t<24 else np.r_[np.zeros(4),np.ones(16)/16]
    lag7=eye[h[-7]] if t>=7 else np.zeros(16)
    f=np.r_[1.,eye[s],pos,eye[last],lag7]
    g=np.r_[f,(eye[s,:,None]*pos[None,:]).ravel(),(eye[s,:,None]*eye[last,None,:]).ravel()]
    k=int(z["permutation"][s]);a=float(np.clip(g@z["confidence"],-30.,30.));success=1/(1+np.exp(-a))
    b=f@z["noise"]+(pos@z["position_modes"])@z["symbol_modes"][:,s,:]
    b[k]=-1e9;q=softmax(b)*(1-success);q[k]=success
    return (q/q.sum()).tolist()
def main():
    a=json.load(sys.stdin)
    if a["vocab_size"]!=16:raise ValueError("Expected the supplied 16-symbol alphabet")
    print(json.dumps({"probabilities":[predict(h) for h in a["histories"]]}))
if __name__=="__main__":main()
