# A five-state, two-regime categorical mechanism

## Generative hypothesis
Choose a regime once per sequence, then run its categorical hidden Markov chain. One regime has three self-looping states with a preferred directed cycle 0 -> 1 -> 2 -> 0; the other has two sticky states 3 and 4. State labels have no semantic meaning. The transition matrix A has separate 3-by-3 and 2-by-2 blocks. Emit x with probability B[state,x], then transition by A. A belief over five states is sufficient for predicting the next symbol. This is a proposed explanatory compression, not a uniquely identified generator.

The fitted prior assigns approximately 0.568 and 0.432 to the two regimes. The cyclic forward probabilities are about .397, .349, .285, with self-loops .603, .645, .670 and small reverse edges. The two-state transitions are about 3->4=.351 and 4->3=.033. State 0 favors tokens {1,14,4}, state 1 {6,9,4}, state 2 {13,3,7}; state 3 favors {6,13,11}, and state 4 {10,7,3}. Exact arrays are in parameters.npz and displayed in parameters.md.

## Executable approximation to the neural predictions
Start with q=init. For each observed symbol x, compute regime mass m_g=sum(q_i in g) and conditional state belief u_i=q_i/m_g. Form

    v_i = m_g**rg * u_i**rw / sum(u_j**rw for j in g)
    posterior_i = v_i * B[i,x] / sum_j(v_j * B[j,x])
    q = posterior @ A

Here rg=0.9491533 and rw=0.7336611. Setting both exponents to one gives ordinary Bayesian HMM filtering. Discounting is an empirically useful approximation to the teacher, not an established generator feature.

The core next-symbol law is p=q@B. A fixed regularized readout uses softmax(log(p)+f@C), where f contains 1, the five q values, a 17-entry latest-symbol indicator, and the 15 products q_i*q_j for i<=j. The extra indicator slot is unused for nonempty histories. C has shape 38-by-16. This explicit readout adapter models residual neural distortion; it adds no latent states and does not change the transition graph. Empty history returns the normalized repeated cached BOS distribution. There is no history lookup, neural execution, fitting at inference, or interaction between rows. Full histories are filtered rather than truncated; beyond the observed lengths this is extrapolation.

The generative core has 87 free stochastic parameters (4 initial, 8 transition, 75 emission). The executable adds two discount scalars, 608 readout coefficients and a BOS vector. It is substantially smaller and structurally different from the supplied two-layer attention architecture.

## Evidence and model selection
Only the supplied 128 token sequences and their 24 prefix distributions were used. No weights, activations, interventions or additional queries were available. The following are exploratory development comparisons, not private test scores:

* Four centered probability directions explain 99.34% of variance; singular values begin 7.52,4.17,3.16,.965, then .437,.320. This motivates, but does not prove, a five-vertex mixture representation.
* Unconstrained five-state HMM fits discover almost disconnected 3+2 components before block structure is imposed. Prefixes classified by this fitted model as confidently cyclic have two dominant directions (3.78,2.56 then .254); those classified as sticky have one (1.09 then .274). These labels are inferred, not independent ground truth.
* Representative HMM validation KL(neural || candidate), fitting rows 0-95 and checking 96-127: 3 states .0561; 4 .0224; 5 .0105; 6 .0098; 10 .0087. Five interpretable states capture most structure without assigning every teacher residual a physical state.
* Removing within-sequence state switching (A=I) gives validation KL .0748 with two categorical sources and .0770 with five, substantially worse. Latest-token conditioning explains only about 48% of probability variance. Bounded suffix filtering also performs worse than retaining all observed evidence.
* The selected hierarchical five-state core gives development KL .00854; its separately fitted regularized readout gives .00707. Joint fitting lowers training loss but is less reliable on validation (.00746). Alternative sequence splits support the five-state filtering explanation; numerical records are in evidence.json. Validation was repeatedly inspected, so estimates are selection-biased.
* After choosing the structure, all 128 supplied sequences were used for an offline final refit. Its cache-fit KL is 0.005715 and RMSE 0.007244; these are explicitly in-sample. The final predictor is frozen and never fits future request histories.

## Prior knowledge, uncertainty and alternatives
Prior knowledge consists of generic categorical state-space modeling, Bayesian filtering, low-rank diagnostics and regularized optimization. No generator family, state count, token semantics or privileged process information was supplied. The five-state count and 3+2 graph were inferred from these observations.

A rare-switching rather than fixed regime, token-labelled state transitions, or a higher-dimensional predictive-state representation remain plausible. Richer fitted automata improve some errors but do not establish additional physical states. Neural approximation, finite data and family mismatch cannot be separated here; the discount factors and readout adapter should not be mistaken for recovered physical laws. Latent states are identifiable at best up to relabeling, and the finite cache cannot prove unique recovery. Long-history and off-distribution behavior remain uncertain despite numerical stability tests.
