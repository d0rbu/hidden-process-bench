"""Two persistent regimes, five categorical states, discounted Bayesian filtering."""
import json
import sys
from pathlib import Path
import numpy as np

def softmax(a):
    e=np.exp(a-np.max(a))
    return e/e.sum()

def predict(history,d):
    if not history:
        return d['bos'].tolist()
    q=d['init'].copy()
    A,B=d['A'],d['B']
    rg,rw=float(d['regime_discount']),float(d['state_discount'])
    for token in history:
        token=int(token)
        if not 0 <= token < 16:
            raise ValueError('History symbols must be integers in [0,15]')
        prior=np.empty(5)
        for ids in (slice(0,3),slice(3,5)):
            group=np.maximum(q[ids],1e-250)
            mass=group.sum()
            within=softmax(rw*np.log(group/mass))
            prior[ids]=rg*np.log(mass)+np.log(np.maximum(within,1e-250))
        q=softmax(prior+np.log(B[:,token]))@A
    last=np.zeros(17)
    last[int(history[-1])]=1.
    feat=np.concatenate(([1.],q,last,[q[i]*q[j] for i in range(5) for j in range(i,5)]))
    prediction=softmax(np.log(np.maximum(q@B,1e-250))+feat@d['calibration'])
    return prediction.tolist()

def main():
    request=json.load(sys.stdin)
    if int(request['vocab_size']) != 16:
        raise ValueError('The inferred alphabet has 16 symbols')
    with np.load(Path(__file__).with_name('parameters.npz'),allow_pickle=False) as d:
        ans=[predict(history,d) for history in request['histories']]
    print(json.dumps({'probabilities':ans},allow_nan=False))

if __name__=='__main__':
    main()
