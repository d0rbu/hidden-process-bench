"""Fixed two-regime categorical filter; standard-library-only JSON predictor."""
import json,sys,math
from pathlib import Path
P=json.loads(Path(__file__).with_name("parameters.json").read_text())
def softmax(a):
 m=max(a);v=[math.exp(x-m) for x in a];z=sum(v);return [x/z for x in v]
def predict(history,vocab_size=16):
 b=[row[:] for row in P["initial"]];r=0.;traces=[[0.]*16 for _ in P["trace_decays"]]
 for token in history:
  evidence=[]
  for k in range(2):
   u=[v*P["recognition"][k][s][token] for s,v in enumerate(b[k])];z=sum(u);evidence.append(z)
   b[k]=[sum(v*row[j] for v,row in zip(u,P["transition"][k]))/z for j in range(len(u))]
  r+=math.log(evidence[0]/evidence[1])
  for trace,decay in zip(traces,P["trace_decays"]):
   for v in range(16):trace[v]*=decay
   trace[token]+=1.
 f=[1.,r]+[math.log(max(v,1e-30)) for group in b for v in group]+[v for trace in traces for v in trace]
 z=[sum(v*row[j] for v,row in zip(f,P["logit_coefficients"])) for j in range(4)]
 gate=1/(1+math.exp(-max(-40.,min(40.,z[0]))))
 w=[gate*v for v in softmax([z[1],z[2],0.])]+[(1-gate)*v for v in softmax([z[3],0.])]
 q=[sum(v*row[t] for v,row in zip(w,P["emissions"])) for t in range(16)]
 return softmax([math.log(max(q[t],1e-30))+sum(v*row[t] for v,row in zip(w,P["readout_correction"])) for t in range(16)])
if __name__=="__main__":
 request=json.load(sys.stdin)
 json.dump({"probabilities":[predict(h,request["vocab_size"]) for h in request["histories"]]},sys.stdout)
