# Two persistent regimes with five categorical predictive modes

## Executable rules
The recurrent core has a three-mode belief b0, a two-mode belief b1, and a scalar cumulative evidence contrast r, initialized from parameters.json and r=0. For observed token x, independently in each regime k:

    u[s] = bk[s] * recognition[k][s][x]
    zk = sum(u)
    bk_next = (u / zk) @ transition[k]
    r_next = r + log(z0 / z1)

In parallel maintain 16-token traces cd <- d*cd + one_hot(x), for d in {0, .5, .8, 1}. These are observed-history summaries, not additional hidden categorical modes. Let f concatenate 1, r, log(b0), log(b1), and the four traces. The fixed 71-by-4 matrix D produces z=f@D. The regime weight is sigmoid(z0); conditional weights are softmax(z1,z2,0) and softmax(z3,0). Their products give five weights w. Then

    q = w @ emissions
    probabilities = softmax(log(q) + w @ readout_correction).

All arrays are frozen. There is no online fitting, communication between rows, teacher access, or use of supplied neural weights at prediction time. The predictor needs only Python's standard library and its adjacent parameter file. Long histories continue these rules without truncation.

## Interpretation
The three-mode block favors a self-looping cycle: mode 0 -> 2 -> 1 -> 0 in the executable's local order. The other block switches between two modes, with its second mode especially persistent. The five emission modes, in readout order, have highest-probability tokens [1, 14, 4, 6], [13, 14, 2, 8], [6, 9, 4, 8], [13, 6, 11, 7], [10, 3, 7, 15]. The first three belong to the three-mode block and the final two to the two-mode block; the final calibration can change output rankings. These are overlapping emissions, not a partition of the alphabet. Slow accumulated regime evidence explains persistence that cannot be reduced to recent tokens. Within-regime filtering explains faster ordered changes. The count traces and affine calibrations accommodate departures from an ordinary HMM in the neural predictions.

The probabilistic core has four belief coordinates: two for the three-mode simplex, one for the two-mode simplex, and one evidence contrast. Four 16-token traces are separate deterministic summaries. Five is the number of categorical predictive modes, not a claim that the complete calibrated recurrence has only five scalar state variables.

## Prior knowledge and uncertainty
Only generic probability, finite-state Bayesian filtering, matrix factorization and regression were assumed. No generating family, number of regimes, graph, or latent-state count was supplied. The graph and five-mode representation were inferred. Stationary recognition factors, positive categorical emissions and first-order within-regime updates are modeling assumptions. Mode labels are arbitrary and parameters are not uniquely identified. Recognition factors differ from emissions: the predictor is an explicit calibrated autoregressive process, not a claim that the neural model implements an exact ordinary HMM. Its numerical calibrations should not be mistaken for recovered physical transition probabilities.

## Evidence and alternatives
See evidence.json for numerical results. A last-token chain has training teacher KL 0.11277, versus roughly 0.0086 for the calibrated mechanism. Probability factorizations and whole-sequence filter comparisons support approximately five predictive modes; four is substantially worse, while six/seven offer modest gains before calibration. A 256-adjacent-pair correction overfits validation and was rejected. Ordinary HMMs, weak inter-regime switching, extra weak modes, and continuous-state alternatives remain possible.

A prospective frozen check gives KL 0.00617 on 128 new mechanism-generated histories, 0.02739 on uniform histories, and 0.01565 on forced regime switches. Matched suffixes of 15 tokens retain strong effects of early regime evidence: teacher pair-TV 0.405, candidate 0.440, difference cosine 0.985. Important limitation: histories matched in token bag and last five tokens still exhibit order effects (teacher pair-TV 0.0591) whose direction is poorly reproduced (cosine 0.099). Thus the mechanism captures persistent regimes much more convincingly than all fine order dependence. Local/global attention and ablation effects are corroborating distributed-computation evidence, not a one-head/one-state identification.

All internal validation was used for model selection; moreover low-rank initializations accessed all cached rows. The prospective check was conducted only after freezing and was not fitted. No private evaluation rows were available. Extension beyond the teacher's 24-position context is an unverified extrapolation.

The four trace decays are hand-chosen recency hyperparameters, selected through a small candidate comparison, not independently recovered latent timescales. The 542 fitted scalar entries exclude these four fixed hyperparameters.
