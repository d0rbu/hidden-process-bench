from method.state_geometry import main
main('outputs')
