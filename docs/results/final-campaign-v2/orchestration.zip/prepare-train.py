import hashlib
import json
import os
import shutil
import subprocess
import sys
from dataclasses import asdict
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parent.parent
commit = '3b14378e6f865f60b205bfdad028f04da1a61130'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == commit
assert not (root / 'protocol.json').exists()
source = root / 'src/hidden_process_bench'
shutil.copytree(repo / 'src/hidden_process_bench', source, ignore=shutil.ignore_patterns('__pycache__'))
for name in ('pyproject.toml', 'uv.lock'):
    shutil.copyfile(repo / name, root / name)
sys.path.insert(0, str(root / 'src'))
from hidden_process_bench.agent_client import restricted_catalog
from hidden_process_bench.discovery_features import prepare_feature_bundle
from hidden_process_bench.experiment import write_json
from hidden_process_bench.mixed_suite import SuiteConfig, prepare_suite, train_suite
from hidden_process_bench.operator_method import prepare_bundle as operators
from hidden_process_bench.research_agent import AgentBudget, PROMPT
from hidden_process_bench.state_geometry import prepare_bundle as geometry
from hidden_process_bench.submissions import file_manifest

methods = [
    {'name': 'operators', 'family': 'classical_identification', 'access': 'outputs', 'bundle': 'method-operators'},
    {'name': 'geometry', 'family': 'belief_state_geometry', 'access': 'outputs', 'bundle': 'method-geometry'},
    {'name': 'pca', 'family': 'learned_representations', 'access': 'internals', 'bundle': 'method-pca'},
    {'name': 'sae', 'family': 'learned_representations', 'access': 'internals', 'bundle': 'method-sae'},
    {'name': 'transcoder', 'family': 'learned_representations', 'access': 'internals', 'bundle': 'method-transcoder'},
    {'name': 'causal', 'family': 'circuit_interventions', 'access': 'internals', 'bundle': 'method-causal'},
    {'name': 'agent_outputs', 'family': 'research_agent', 'access': 'outputs', 'bundle': None},
    {'name': 'agent_internals', 'family': 'research_agent', 'access': 'internals', 'bundle': None},
]
operators(root / 'method-operators')
geometry(root / 'method-geometry', 'outputs')
geometry(root / 'method-pca', 'activations')
for mode in ('sae', 'transcoder', 'causal'):
    prepare_feature_bundle(root / ('method-' + mode), mode)
budget = AgentBudget()
binary = Path('/home/d0rb/.npm/_npx/bfd05e0424263c63/node_modules/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl/bin/codex')
catalog = root / 'catalog.json'
write_json(catalog, restricted_catalog(Path('/home/d0rb/.codex/models-ultrafast-0.159.2.json'), 'gpt-6.1-sol'))
config = SuiteConfig(train_steps=8000, eval_sequences=2048, validation_margin=0.8)
protocol = {
    'schema_version': 1, 'stage': 'frozen_before_new_task_generation',
    'source_commit': commit, 'source_sha256': file_manifest(source),
    'methods': methods,
    'method_sha256': {m['name']: file_manifest(root / m['bundle']) for m in methods if m['bundle'] is not None},
    'agent': {'protocol_version': 2, 'budget': asdict(budget), 'prompt': PROMPT.format(**asdict(budget)), 'model': 'gpt-6.1-sol', 'reasoning': 'xhigh', 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'catalog_sha256': hashlib.sha256(catalog.read_bytes()).hexdigest(), 'parallel_trials': 2},
    'teacher_config': asdict(config), 'teacher_case_wall_seconds': 600,
    'training_change_reason': 'The development suite retained one unqualified deep-stack case. This fresh entire suite allows 8000 steps and 2048 qualification sequences while retaining the original 0.03 overall/every-group upper95 criterion. Test used once; no resumed training from test feedback.',
    'qualification': 'All six frozen teachers must pass overall and every process group on separate stopping validation and final test. No qualified-subset final campaign.',
    'method_limits': {'wall_seconds': 30, 'cpu_seconds': 20, 'memory_mb': 1024},
    'scoring': {'sequences': 128, 'short_length': 24, 'long_length': 72, 'oracle_and_teacher_kl_separate': True, 'long_teacher_defined': False, 'sequence_standard_errors': True, 'row_invariance_probes': True, 'diagnostic_total_variation_witnesses_after_registration': True},
    'independent_discovery_boundary': 'Neutral anonymous packets and arbitrary executable submission. No family/order, HMM adapter, private processes, seeds, qualification or score feedback given to methods. All methods/source fixed before these tasks; all 48 trials must terminate and register before any private final scoring.',
    'structural_review': 'Assess actual executable dependencies and update rules against the private source after registration. Accept equivalent representations and do not require a supplied family schema. Family labels, selected dimensions and predictive KL alone do not establish recovered structure. Report partial structure, parameter alignment only if the method itself proposes a compatible representation, equivalence diagnostics versus exact certificates, minimality evidence and causal evidence separately. Preserve incompatible/failed/unresolved submissions.',
    'causal_scope': 'Head pruning measures neural output effects only; no semantic process/circuit intervention alignment is built into this method. Do not label pruning alone causal process recovery.',
    'comparison_limits': 'Cached histories/probabilities are paired byte-for-byte. Internal variants can execute weights and interventions and must report counts. This is not equal-query/compute matching, nor an information-theoretic weights-vs-outputs claim. Restricted linear-state and algebraic recognition priors are disclosed; only the agent can choose arbitrary programs.',
    'failure_policy': 'Preserve every prepared/rejected/unqualified/failed/timeout case. No rescue of unsubmitted artifacts, selective retry, source change, task replacement or private feedback. Abort extraction if the whole suite is not qualified.',
    'development_agent_wait': 'Before final agent calls, wait for the already-running ten-trial development cohort to finish, without copying its hypotheses or scores into final contexts. No final method adaptation is permitted.',
}
prior = json.loads((repo / 'outputs/final-campaign-v1/protocol.json').read_text())
assert protocol['method_sha256'] == prior['method_sha256']
assert protocol['agent'] == prior['agent']
protocol['previous_attempt'] = {'path': 'outputs/final-campaign-v1', 'qualified': 5, 'planned': 6, 'extraction_started': False, 'method_adaptation': False, 'change': 'Only stopping validation is tightened to 0.024; final test remains 0.03. Entirely new tasks and random streams; no resumed failed teacher.'}
write_json(root / 'protocol.json', protocol)
suite = repo / 'outputs/private-final-suite-v2'
prepared = prepare_suite(config, suite)
plan = json.loads((suite / 'private/plan.json').read_text())
new_seeds = {seed for case in plan['cases'] for seed in case['seeds'].values()}
for old_suite in ('private-mixed-pilot-v2', 'private-final-suite-v1'):
    old_plan = json.loads((repo / 'outputs' / old_suite / 'private/plan.json').read_text())
    assert new_seeds.isdisjoint({seed for case in old_plan['cases'] for seed in case['seeds'].values()})
write_json(root / 'suite-binding.json', {'protocol_sha256': hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest(), 'private_plan_sha256': hashlib.sha256((suite / 'private/plan.json').read_bytes()).hexdigest(), 'roster': [{'id': case['id'], 'method': method['name'], 'access': method['access']} for case in plan['cases'] for method in methods], 'all_methods_fixed_before_training': True})
if not prepared['all_prepared']:
    write_json(root / 'training-result.json', {'campaign_ready': False, 'reason': 'preparation_failed_no_extraction_started'})
    raise SystemExit(2)
# Child processes import the same immutable source capsule as this parent.
os.environ['PYTHONPATH'] = str(root / 'src')
summary = train_suite(suite, timeout=600)
write_json(root / 'training-result.json', {'campaign_ready': summary['campaign_ready'], 'summary_sha256': hashlib.sha256((suite / 'private/training-summary.json').read_bytes()).hexdigest(), 'extraction_started': False})
print(json.dumps({'campaign_ready': summary['campaign_ready'], 'cases': len(summary['cases'])}), flush=True)
raise SystemExit(0 if summary['campaign_ready'] else 2)
