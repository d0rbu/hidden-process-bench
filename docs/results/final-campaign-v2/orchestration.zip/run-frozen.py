import hashlib
import json
import shutil
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import numpy as np

root = Path(__file__).resolve().parent
repo = root.parent.parent
sys.path.insert(0, str(root / 'src'))
from hidden_process_bench.discovery import extract_process, score_process
from hidden_process_bench.experiment import write_json
from hidden_process_bench.isolation import Limits
from hidden_process_bench.research_agent import AgentBudget, run_agent
from hidden_process_bench.submissions import FrozenSubmission, file_manifest, verify_submission

assert not (root / 'execution-plan.json').exists(), 'do not repeat a final campaign'
protocol = json.loads((root / 'protocol.json').read_text())
binding = json.loads((root / 'suite-binding.json').read_text())
assert binding['protocol_sha256'] == hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest()
current_source = file_manifest(root / 'src/hidden_process_bench')
added = set(current_source) - set(protocol['source_sha256'])
if added:
    # This scorer import is new relative to preparation; retain its derived cache
    # outside the frozen package, without changing any declared file or source byte.
    assert added == {'__pycache__/discovery.cpython-313.pyc'}
    cache = root / 'execution-generated-cache'
    cache.mkdir(exist_ok=False)
    for name in added:
        shutil.move(root / 'src/hidden_process_bench' / name, cache / Path(name).name)
    write_json(root / 'execution-cache-audit.json', {'extra_generated_bytecode': {name: current_source[name] for name in added}, 'declared_source_files_changed': False, 'first_attempt_before_any_extraction': True})
assert file_manifest(root / 'src/hidden_process_bench') == protocol['source_sha256']
for method in protocol['methods']:
    if method['bundle'] is not None:
        assert file_manifest(root / method['bundle']) == protocol['method_sha256'][method['name']]
suite = repo / 'outputs/private-final-suite-v2'
assert binding['private_plan_sha256'] == hashlib.sha256((suite / 'private/plan.json').read_bytes()).hexdigest()
qualification = json.loads((suite / 'private/training-summary.json').read_text())
assert qualification['campaign_ready'] and len(qualification['cases']) == 6
assert all(row['status'] == 'qualified' for row in qualification['cases'])
assert len(binding['roster']) == 48
case_ids = sorted({row['id'] for row in binding['roster']})
for case in case_ids:
    with np.load(suite / 'public' / case / 'outputs/observations.npz') as a:
        with np.load(suite / 'public' / case / 'internals/observations.npz') as b:
            assert np.array_equal(a['tokens'], b['tokens'])
            assert np.array_equal(a['probabilities'], b['probabilities'])
binary = Path('/home/d0rb/.npm/_npx/bfd05e0424263c63/node_modules/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl/bin/codex')
assert hashlib.sha256(binary.read_bytes()).hexdigest() == protocol['agent']['binary_sha256']
assert hashlib.sha256((root / 'catalog.json').read_bytes()).hexdigest() == protocol['agent']['catalog_sha256']
write_json(root / 'execution-plan.json', {
    'protocol_sha256': binding['protocol_sha256'],
    'private_plan_sha256': binding['private_plan_sha256'],
    'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'all_six_teachers_qualified': True, 'all_48_trials_required_before_private_scoring': True,
    'all_methods_fixed_before_task_generation': True,
    'paired_cached_observations_equal': True,
    'private_feedback': False,
})
methods = {method['name']: method for method in protocol['methods']}
rows = []
def retain(row):
    rows.append(row)
    write_json(root / 'progress.json', {'trials': rows, 'private_scoring_started': False})
    print(json.dumps({'id': row['id'], 'method': row['method'], 'status': row['status']}), flush=True)

for trial in binding['roster']:
    method = methods[trial['method']]
    if method['bundle'] is None:
        continue
    out = root / trial['id'] / trial['method']
    frozen = extract_process(root / method['bundle'], 'main.py', suite / 'public' / trial['id'] / trial['access'], out / 'extraction', limits=Limits(**protocol['method_limits']))
    if frozen is not None:
        verify_submission(frozen)
    retain({**trial, 'status': 'submitted' if frozen is not None else 'failed', 'submission_receipt_sha256': None if frozen is None else frozen.receipt_sha256, 'path': str(out.relative_to(root) / 'extraction/submission')})

# Admission depends only on a terminal development registration, never its private scores.
development = repo / 'outputs/agent-development-v2/registration.json'
write_json(root / 'waiting-for-development.json', {'required_registration': str(development), 'final_agent_trials_started': False, 'remaining_final_agent_trials': 12})
deadline = time.monotonic() + 10800
while not development.exists():
    if time.monotonic() >= deadline:
        raise TimeoutError('development registration did not complete within three-hour admission cap; no final agent calls or private scores started')
    time.sleep(5)
registered = json.loads(development.read_text())
assert registered['all_ten_finished_before_private_scoring'] and len(registered['trials']) == 10
write_json(root / 'agent-admission.json', {'development_registration_sha256': hashlib.sha256(development.read_bytes()).hexdigest(), 'final_agent_trials': 12, 'development_scores_or_hypotheses_provided': False})

def agent_trial(trial):
    out = root / trial['id'] / trial['method']
    frozen = run_agent(suite / 'public' / trial['id'] / trial['access'], binary, root / 'catalog.json', out, budget=AgentBudget(**protocol['agent']['budget']))
    if frozen is not None:
        verify_submission(frozen)
    return {**trial, 'status': 'submitted' if frozen is not None else 'failed', 'submission_receipt_sha256': None if frozen is None else frozen.receipt_sha256, 'path': str(out.relative_to(root) / 'submission'), 'trial': json.loads((out / 'trial.json').read_text())}

with ThreadPoolExecutor(max_workers=2) as executor:
    futures = [executor.submit(agent_trial, trial) for trial in binding['roster'] if methods[trial['method']]['bundle'] is None]
    for future in as_completed(futures):
        retain(future.result())
assert len(rows) == 48
assert {(x['id'], x['method']) for x in rows} == {(x['id'], x['method']) for x in binding['roster']}
write_json(root / 'registration.json', {'trials': rows, 'all_48_finished_before_any_private_final_scoring': True})
write_json(root / 'scoring-plan.json', {'registration_sha256': hashlib.sha256((root / 'registration.json').read_bytes()).hexdigest(), **protocol['scoring']})
scores = []
for row in sorted(rows, key=lambda x: (x['id'], x['method'])):
    private = suite / 'private' / row['id']
    result = {**row, 'family_after_registration': json.loads((private / 'process.json').read_text())['family']}
    if row['submission_receipt_sha256'] is not None:
        frozen = FrozenSubmission(root / row['path'], row['submission_receipt_sha256'])
        verify_submission(frozen)
        for split in ('heldout', 'long'):
            out = root / row['id'] / row['method'] / ('score-' + split)
            with np.load(private / 'training' / (split + '.npz'), allow_pickle=False) as data:
                result[split] = score_process(frozen, data['tokens'], data['oracle'], data.get('teacher'), out)
                if result[split]['status'] == 'scored':
                    with np.load(out / 'predictions.npz', allow_pickle=False) as predictions:
                        difference = np.abs(predictions['probabilities'] - data['oracle']).sum(axis=-1) / 2
                        result[split + '_max_total_variation'] = float(difference.max())
                        sequence, position = np.unravel_index(difference.argmax(), difference.shape)
                        write_json(out / 'diagnostic-witness.json', {'history': data['tokens'][sequence, :position].tolist(), 'oracle_probabilities': data['oracle'][sequence, position].tolist(), 'candidate_probabilities': predictions['probabilities'][sequence, position].tolist(), 'total_variation': float(difference[sequence, position]), 'selected_after_registration': True})
    scores.append(result)
    write_json(root / 'score-progress.json', {'trials': scores})
    print(json.dumps({'id': row['id'], 'method': row['method'], 'score_stage_complete': True}), flush=True)
write_json(root / 'report.json', {'final_campaign': True, 'all_48_finished_before_private_scoring': True, 'all_six_teachers_qualified': True, 'trials': scores, 'structure_assessment': 'pending_independent_review', 'independent_structure_recovery': None, 'causal_recovery': None})
