from method.state_geometry import main
main('activations')
