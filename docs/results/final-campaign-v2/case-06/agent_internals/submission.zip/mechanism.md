# Colored pending-opening memory

## Structural hypothesis
The dominant dependency is a two-color matching process with variable-length memory. Tokens 15 and 7 open colors A and B; tokens 4 and 5 close A and B respectively. The other twelve tokens are neutral. On well-matched strings, the memory is a conventional typed LIFO stack.

The chosen update rule maintains an ordered list of pending openings, each carrying its color and position. An opening appends an item. A close removes the most recent pending opening of its corresponding color, if present. An unmatched close and a neutral token leave this structural memory unchanged. The most recent surviving opening determines the preferred closing token.

Equivalently, maintain a timestamp stack for each color and compare their latest timestamps. This requires ordering information, not merely two counters. Three emission prototypes do NOT imply three latent states: the pending memory has variable length and many possible contents.

Color-selective cancellation is an empirical extension to malformed strings, not proof about an unknown original generator. A strict typed stack might reject mismatches or ignore them; the available off-manifold teacher probes favor selective cancellation on average.

## Fixed probability rule
Let E_empty, E_B and E_A be the three categorical vectors in emissions.npy. Empty memory emits E_empty. Otherwise, for current color c,

    p(next | history) = (1-rho) E_empty + rho E_c
    rho = sigmoid(b_c dot f(history)).

The categorical prototypes use 48 scalar values and the two confidence regressions use 66: 114 fitted scalar values in total. The output is explicitly normalized. No neural weights, neural operations, stored examples, or evaluation-time fitting are used.

The empty prototype assigns approximately half the mass to the two closes combined, divided nearly equally. A confidently retrieved A shifts almost all closing mass to 4; B shifts it to 5. Openings each retain approximately .15 mass, and the twelve neutral symbols approximately .20 combined. Small context-dependent changes outside the close contrast are retained in the fitted prototypes rather than asserted to be fundamental source rules.

The 33 selected feature names are in feature_names.json; feature_indices.npy selects them from the transparent statistics in structure.py. They describe neutral delay; same/opposite-color events since the retrieved item; pending depth; crossing and unmatched closes; interference products and thresholds; total and peak structural load; the last removed color; the second pending color; and recent structural density.

The confidence rule corrects approximate neural retrieval. It is not a claim that an ideal matching grammar randomly forgets. Complete input histories are processed without neural-context truncation. The simple reference implementation scans pending lists and can take quadratic time on adversarial crossing histories; memory use is linear.

## Priors, uncertainty and alternatives
No generating family, latent count, grammar or token roles were supplied. Methodological prior knowledge consisted of categorical models, Markov alternatives, stacks, linear probes, causal ablation and regularized regression. Parsimony and explicit update rules were preferences; token identities and the memory dependency were inferred from challenge-only numerical evidence.

The strongest conclusion is colored nested matching with neutral insertions and nearly context-independent opening/neutral emissions. Exact source probabilities, malformed-string semantics, depth limits and behavior beyond the observed context remain uncertain. The confidence regression extrapolates outside its fitting range and is not a verified long-horizon theory.

IID, first-order, last-opening reset, FIFO, untyped-pop and strict typed-pop alternatives were considered. Nested retrieval defeats IID, first-order and reset explanations as adequate accounts. FIFO performed worse. A sufficiently large finite-state process could match every finite test, and finite evidence cannot establish an actually infinite stack or a uniquely identifiable grammar. Sparse mismatches can reflect source noise, neural approximation, or both.

See evidence.md, validation.json and execution_accounting.json for measurements and resource accounting.
