import sys,json
from pathlib import Path
import numpy as np
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D))
from structure import features
E=np.load(D/'emissions.npy')
B=np.load(D/'reliability.npy')
I=np.load(D/'feature_indices.npy')
def predict(history):
 top,f=features([int(t) for t in history])
 if not top:
  q=E[0].copy()
 else:
  j=1 if top==7 else 2
  confidence=float(1/(1+np.exp(-np.clip(f[I]@B[j-1],-30,30))))
  q=E[0]+confidence*(E[j]-E[0])
 q=np.maximum(q,1e-15)
 return (q/q.sum()).tolist()
def main():
 request=json.load(sys.stdin)
 if request['vocab_size']!=16:
  raise ValueError('The inferred source has sixteen observable symbols.')
 print(json.dumps({'probabilities':[predict(h) for h in request['histories']]}))
if __name__=='__main__':main()
