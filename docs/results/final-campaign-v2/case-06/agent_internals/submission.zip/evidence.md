# Evidence and fitting record

All task evidence came from /challenge and numerical execution of the supplied helper. No evaluator, external data, private scores or generating-process hints were used. This explains teacher predictions, not a proven recovery of its training generator.

## Structural evidence
* The supplied cache contains 128 length-24 sequences and 3072 probability vectors. Centered predictive singular values begin 13.054, .464, .280 and .139. The dominant contrast is token 4 versus token 5; other coordinates vary much less.
* Ratios here mean P(4)/(P(4)+P(5)). Controlled prefixes [15,4] give .510; [15,15,4] .996; [15,7,5] .995; [7,15,4] .009. Closing an item can expose an older color, rather than simply resetting or retaining the latest opening.
* Mismatched [15,5] retains A (.994), while crossing [15,7,4,5] is nearly empty (.588). Pop-every-close and ignore-mismatch typed stacks each miss some neural behavior. Selective cancellation is a tested extension, but crossing semantics remain uncertain.
* On exploratory holdouts, FIFO matching had KL .06465 on source-like and .06381 on malformed prefixes, versus selective LIFO .02019 and .03337. Pop-every-close gave .04841 and .15682. These comparisons used the same three-prototype fitting scheme.
* A basic exact-stack emission model achieved all-cache KL .01094 and TV .01732. Retrieval of older pending items was less reliable than retrieval immediately following an opening.
* Neutral delay differs from interference: [15] followed by eight zeros retains A (.994). Five 15s followed by four 4s give .536; nine followed by eight give .507. The analogous B tests give .430 and .471. This motivated the structural confidence correction.

## Neural evidence, not a copied implementation
A 32-sequence helper reproduction matched cached predictions within 3.73e-7. Individual head ablations gave mean KL changes .00080 through .01742. Removing MLP 0 or 1 gave .09972 and .06217. A regularized linear stack-top readout from final normalized residuals reached heldout R-squared .955 on a small 22/10 sequence split. This is consistent with distributed matching computation, not proof that the network literally contains a symbolic stack. No neural readout is in the predictor.

## Fitting and selection
An independent categorical baseline was written early, then replaced incrementally by a parser and prototypes, then the current small confidence correction. The declared cache split was 88 training and 40 validation sequences. Prototypes were estimated from training-cache empty memories and immediately preceding opening tokens. Confidence fitting used those 88 sequences plus 96 source-like and 64 malformed exploratory sequences. Cache training examples received twice the weight of exploratory examples.

Fitting minimized teacher KL with deterministic Adam and L2 regularization. Feature variants used 22, 45 and a reduced 33 terms per color. Regularization candidates were .00002, .0002 and .001. The reduced representation with .0002 regularization was selected for compactness and established validation performance; its fit used 2600 optimizer iterations. These validation sets influenced selection and are not blind benchmarks.

A separate fresh 192-sequence teacher set provided confirmation, without fitting: 64 source-like, 64 strictly matched-close and 64 malformed sequences. Scores for alternatives, including some better individual results, remain disclosed in validation.json. No refitting followed this confirmation.

Final fixed candidate, mean KL / total variation:

| Heldout set | KL | TV |
|---|---:|---:|
| Supplied cache, last 40 sequences | .003070 | .013124 |
| Exploratory source-like, 32 sequences | .009331 | .019908 |
| Exploratory malformed, 64 sequences | .018165 | .023893 |
| Fresh source-like, 64 sequences | .004200 | .014337 |
| Fresh strict matching, 64 sequences | .005371 | .014516 |
| Fresh malformed, 64 sequences | .016429 | .023801 |

These measure teacher agreement, not true-source likelihood or private evaluation performance. They support useful structural compression, not exact equivalence. Explicit final normalization only corrects floating-point probability-sum errors. The frozen interface is tested for positivity, normalization, determinism, repeated rows and histories longer than the neural context.
