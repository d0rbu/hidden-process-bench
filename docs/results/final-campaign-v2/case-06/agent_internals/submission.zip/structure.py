import numpy as np

def base_features(h):
 s=[];removed=[];mismatch=0
 for t,tok in enumerate(h):
  if tok in (7,15):s.append((int(tok),t))
  elif tok in (4,5):
   want=15 if tok==4 else 7
   for j in range(len(s)-1,-1,-1):
    if s[j][0]==want:
     if j!=len(s)-1:mismatch+=1
     removed.append((s[j][0],s[j][1],t));s.pop(j);break
 top=s[-1][0] if s else 0
 birth=s[-1][1] if s else (removed[-1][1] if removed else len(h))
 tail=h[birth+1:] if birth<len(h) else []
 same=15 if top==15 else 7 if top==7 else (removed[-1][0] if removed else 15)
 other=7 if same==15 else 15
 close=4 if same==15 else 5;oclose=5 if same==15 else 4
 ns=tail.count(same);no=tail.count(other);nc=tail.count(close);noc=tail.count(oclose)
 age=len(tail);neutral=age-ns-no-nc-noc
 # Features measure interference since the currently retrieved item, not arbitrary n-grams.
 v=[1.,min(age,30)/10,min(neutral,30)/10,ns/4,no/4,nc/4,noc/4,(ns+no)/4,(nc+noc)/4,
    min(len(s),10)/5,min(mismatch,5)/3,
    float(bool(h) and h[-1] in (4,5)),float(bool(h) and h[-1] in (7,15)),
    ns*nc/16,no*noc/16,(ns+no)*(nc+noc)/16,
    float(ns>=2),float(no>=2),float(nc>=2),float(noc>=2),float(age>=6),float(age>=10)]
 return top,np.asarray(v,float)


def features(h):
 top,f=base_features(h)
 a=b=0;ua=ub=0;ma=mb=0;total=[];pending=[];removed=[];cross=0
 for i,tok in enumerate(h):
  if tok==15:a+=1;ma=max(ma,a);pending.append((tok,i))
  elif tok==7:b+=1;mb=max(mb,b);pending.append((tok,i))
  elif tok in (4,5):
   want=15 if tok==4 else 7
   if tok==4:
    if a:a-=1
    else:ua+=1
   else:
    if b:b-=1
    else:ub+=1
   for k in range(len(pending)-1,-1,-1):
    if pending[k][0]==want:
     cross+=int(k!=len(pending)-1);removed.append(pending.pop(k)+(i,));break
  total.append(a+b)
 n=len(h);same=15 if top==15 else 7;close=4 if same==15 else 5
 ns=h.count(same);nc=h.count(close);no=h.count(7 if same==15 else 15);noc=h.count(5 if same==15 else 4)
 mx=max(total,default=0);past=max(total[:-3],default=0)
 g=[n/24,ns/8,nc/8,no/8,noc/8,(ua if same==15 else ub)/5,(ub if same==15 else ua)/5,
    mx/6,past/6,(ma if same==15 else mb)/6,(mb if same==15 else ma)/6,
    nc*nc/64,noc*noc/64,nc*noc/64,ns*nc/64,no*noc/64,
    float(bool(removed) and removed[-1][0]==same),float(bool(removed) and removed[-1][0]!=same),
    float(len(pending)>1 and pending[-2][0]!=same),float(len(pending)>1 and pending[-2][0]==same),
    sum(t in (4,5,7,15) for t in h[-6:])/6,
    float(n>0)*len(pending)/max(n,1),cross/4]
 return top,np.concatenate([f,np.array(g)])
