import sys,json
from pathlib import Path
import numpy as np
P=np.load(Path(__file__).with_name('parameters.npz'))
E=P['emissions'];B=P['coefficients'];SEL=P['selection'].astype(int)
CAP=int(P['capacity']);S=np.arange(1,2**(CAP+1));NS=len(S)
DEP=np.floor(np.log2(S)).astype(int);TOP=np.where(S==1,0,np.where(S%2==0,1,2));I=np.eye(NS)
def mat(dest):
 m=np.zeros((NS,NS));m[np.arange(NS),np.asarray(dest,dtype=int)-1]=1.;return m
bottom=np.where(S>1,2**np.maximum(DEP-1,0)+S%(2**np.maximum(DEP-1,0)),1)
age=(1-float(P['forget']))*I+float(P['forget'])*mat(bottom)
M=np.repeat(I[None],16,axis=0)
for a in (15,7):
 n=2*S+(a==7);n=np.where(n>=2**(CAP+1),2**CAP+n%(2**CAP),n);M[a]=mat(n)
for a,k in [(4,1),(5,2)]:
 pr=np.where(TOP==k,float(P['matched_pop']),float(P['wrong_pop']));M[a]=pr[:,None]*mat(np.maximum(S//2,1))+(1-pr[:,None])*I
M=age[None]@M

def predict_one(h):
 b=np.zeros(NS);b[0]=1.;st=[];lp=-1;lc=0;uf=0;bad=0;pushes=0;lasttyp=0
 for t,a in enumerate(h):
  b=b@M[a]
  if a in (7,15):
   typa=1 if a==15 else 2;st.append((typa,t,pushes));pushes+=1;lp=t;lasttyp=typa
  elif a in (4,5):
   lc=a
   if st:bad+=int((a==4)!=(st[-1][0]==1));st.pop()
   else:uf+=1
 t=len(h);typ=st[-1][0] if st else 0;ag=t-st[-1][1] if st else 0;pairs=pushes-st[-1][2]-1 if st else 0
 f=np.array([1,t/24,min(len(st),5)/5,max(0,len(st)-4)/4,min(ag,20)/10,max(0,ag-4)/10,max(0,ag-8)/10,min(t-lp,20)/10,pairs/5,uf/8,bad,lc==4,lc==5,typ==1,typ==2,typ==0,typ==1 and ag>1 and pairs>0,typ==2 and ag>1 and pairs>0,typ==1 and ag>5,typ==2 and ag>5,ag/10 if typ==1 else 0,ag/10 if typ==2 else 0,typ==0 and lasttyp==1,typ==0 and lasttyp==2],float)
 # Beyond observed lengths, saturate calibration covariates, not the memory.
 f=np.minimum(f,np.array([1,1,1,2,2,2,2,2,3,3,3,1,1,1,1,1,1,1,1,1,2.4,2.4,1,1]))
 w=np.array([b[TOP==k].sum() for k in range(3)])
 if len(SEL):
  z=np.log(w+.002)+f[SEL]@B;z-=z.max();w=np.exp(z);w/=w.sum()
 q=w@E;q=np.maximum(q,1e-15);return (q/q.sum()).tolist()

def main():
 d=json.load(sys.stdin)
 if d['vocab_size']!=16:raise ValueError('This inferred categorical mechanism has vocabulary 16.')
 print(json.dumps({'probabilities':[predict_one(h) for h in d['histories']]}))
if __name__=='__main__':main()
