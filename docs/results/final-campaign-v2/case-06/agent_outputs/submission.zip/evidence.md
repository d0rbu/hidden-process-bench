# Evidence and validation

Only /challenge/observations.npz was used numerically: 128 sequences, 24 aligned pre-token predictions each, vocabulary 16. The contract and declared architecture were read; no weights or traces were available. No teacher queries or neural executions were performed.

The centered probability matrix has singular values 13.054, 0.4645, 0.2801, 0.1394, then below 0.04. The dominant direction exchanges mass between tokens 4 and 5. Immediately after 15, mean (P4,P5) is (0.5142,0.0023); after 7 it is (0.0030,0.4877). In 155 cached nested closures exposing an older opposite-type opener, 151 next predictions favor that older type's closer. Thus the last opener alone is insufficient.

First 96 sequences were initially used for fitting and the last 32 for exploratory validation. Forward KL in nats/prediction:
- First-order categorical baseline: 0.049004.
- Stack capacity 1 / 2 / 3: 0.035215 / 0.012360 / 0.006670.
- Unbounded exact LIFO: 0.007174; unbounded FIFO: 0.070756.
- Clear all memory on a closer: 0.035215.
- Selected input-driven noisy stack without calibration: 0.003702.
- Coherent Bayesian noisy stack chosen by training loss: 0.004282.

These alternatives were tested, not merely proposed. Other explored corrections included explicit parser mixtures, event-dependent deletion/extra pops, and soft height-addressed retrieval. The simpler input-driven stack was retained as the calibration base. Mean absolute closer-contrast error of the exact stack increases from 0.0067 at opener age one to 0.1666 at ages 9–12. Only 11 observed closers mismatch its top, limiting inference about malformed histories.

Four sequence-block folds compared no reliability gate, six explicit summaries, and 24 summaries. Mean held-out (KL, TV) was respectively (0.005136, 0.014223), (0.005150, 0.014358), and (0.004986, 0.014088). The full gate was selected, but its advantage is small and inconsistent across folds. Structural hyperparameters were explored on these same observations, so these are internal, selection-affected diagnostics, not a blind generalization guarantee.

After selection, emissions and the gate were fitted to all cached vectors and frozen. In-sample KL/TV: 0.004037/0.013667. Standalone predictions agree with the vectorized fixed-parameter computation to 2.2e-16. Interface tests cover empty histories/batches, duplicate and reversed rows, nested/mismatched closures, normalization, and length-600 histories. No cached rows, original neural code or challenge dependencies are shipped.
