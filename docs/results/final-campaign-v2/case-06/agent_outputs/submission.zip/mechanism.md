# Two-type noisy pushdown mechanism

## Structural hypothesis
Tokens 15 and 7 open two kinds of nested dependency, whose preferred closing tokens are 4 and 5 respectively. The other twelve tokens are structurally inert. Start with an empty stack. An opener pushes its type; a closer ordinarily removes the top. At empty stack both closers are possible; otherwise the top strongly favors its matching closer. This accounts for the dominant changing probability mass. The three emission conditions (empty, top-15, top-7) are not three total latent states: older stack entries matter after a pop.

This is an inferred structure, not a supplied family or state count. Generic prior knowledge comprised categorical Markov chains, finite-memory/hidden-state models and stack automata. Token identities, pairings and the preference for LIFO memory came from the cached histories and probabilities.

## Exact submitted prediction rule
The predictor implements a small **predictive memory transducer**, not a copy of the neural network:

1. Maintain a probability distribution b over all binary stacks of length at most four, initially concentrated on empty. These 31 configurations are enumerated algorithmically, not fitted as unrelated hidden states.
2. Before each observed token, remove the oldest entry with probability 0.025 (empty is unchanged). An opener then pushes its type, dropping the oldest entry on overflow. A closer pops with probability 0.98 when it matches the top, and 0.30 otherwise; a failed pop does nothing. Other tokens do nothing after the memory-loss step. Propagate b exactly, without sampling.
3. Sum b into three masses w for empty/top-15/top-7. Alongside b, maintain an ordinary exact stack that pops on either closer. Its summaries describe memory reliability, not a second learned token model.
4. Calibrate these masses as g = softmax(log(w + 0.002) + f B). The 24 explicitly defined summaries f in predictor.py concern length, depth/overflow, top age, age hinges, last-push age, enclosed pairs, empty-stack closes, type mismatches, last closer, top/empty indicators and their type/age interactions. B is a fixed 24-by-3 coefficient table, fitted with L2 penalty 0.0001. The correction is phenomenological and only modestly improves internal validation.
5. Return q = g E. E contains three normalized 16-token categorical emission rows. Their (P4,P5) values are approximately (0.2475,0.2426), (0.5126,0.0007), and (0.0025,0.4865). Full rows and B are in parameters.npz.

Stack transitions and all summaries are literal deterministic code. There is no likelihood reweighting of b by the observed token: b is a predictive uncertainty representation, not a claimed Bayesian posterior over the original generator. Fixed constants, 72 calibration coefficients and three categorical laws replace the entire neural model. No training occurs at prediction time.

## Uncertainty and alternatives
Evidence for the two pairings and nested LIFO order is strong. Exact capacity, forgetting and invalid-closer behavior are weakly identified. Capacity four is a regularized approximation to neural memory, not proof that the source grammar has a four-entry limit. An unbounded stochastic grammar implemented imperfectly by the neural model is a plausible underlying account. Ignoring a wrong-type closer, popping it, or removing the latest matching opener are hard to distinguish because such events are rare. FIFO, clear-on-close and one-entry memories fit worse. A coherent Bayesian noisy-stack alternative was tested but did not improve the selected predictive rule.

No histories beyond length 23 were supplied as prediction prefixes. Longer histories are processed in full; reliability covariates saturate at the fixed bounds in predictor.py, while stack updates continue. This is an explicit extrapolation assumption, not validated long-context behavior. Remaining discrepancies, especially aged/deep retrieval, are not evidence that the fitted forgetting probabilities are literal generator parameters.
