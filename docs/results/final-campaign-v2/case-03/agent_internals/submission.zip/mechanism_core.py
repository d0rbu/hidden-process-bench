"""Minimal idealized generator; calibration is deliberately omitted."""
import json,sys
PERM=(2,12,6,15,11,7,8,4,9,5,13,1,14,0,10,3)
def predict(history):
 if len(history)<3:return [1/16]*16
 q=[0.2/15]*16;q[PERM[history[-3]]]=0.8;return q
def sample_next(history,rng):
 if len(history)<3:return rng.randrange(16)
 target=PERM[history[-3]]
 if rng.random()<0.8:return target
 draw=rng.randrange(15);return draw+(draw>=target)
if __name__=='__main__':
 d=json.load(sys.stdin)
 if d['vocab_size']!=16:raise ValueError('Expected 16 symbols')
 print(json.dumps({'probabilities':[predict(h) for h in d['histories']]}))
