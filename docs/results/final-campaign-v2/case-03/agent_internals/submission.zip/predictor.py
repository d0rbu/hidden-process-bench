import json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
with np.load(ROOT/'parameters.npz') as z:P={k:z[k] for k in z.files}
SPEC=json.loads((ROOT/'calibration_spec.json').read_text())['spec']
with np.load(ROOT/'calibration.npz') as z:W=[z['w'+str(j)] for j in range(len(SPEC))]
def normalize(logits):
 logits=logits-logits.max();q=np.exp(logits);return (q/q.sum()).tolist()
def predict(h):
 n=len(h)
 if n==0:return P['start'].tolist()
 if n==1:return P['first'][h[0]].tolist()
 if n==2:return normalize(P['second_first'][h[0]]+P['second_last'][h[1]])
 src=h[-3];pos=min(n,23)-3;logits=np.log(P['transition'][src]).copy()
 for (kind,lag),w in zip(SPEC,W):
  if kind=='source':idx=src
  elif kind=='position':idx=pos
  elif kind=='source_position':idx=src*21+pos
  else:
   if n<lag:continue
   idx=h[-lag] if kind=='lag' else src*16+h[-lag]
  logits+=w[idx]
 return normalize(logits)
if __name__=='__main__':
 d=json.load(sys.stdin)
 if d['vocab_size']!=16:raise ValueError('This mechanism has 16 categorical symbols')
 print(json.dumps({'probabilities':[predict(h) for h in d['histories']]}))
