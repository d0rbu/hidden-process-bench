# Three interleaved noisy substitution chains

## Structural mechanism
Symbols are categorical, not numbers. The dominant law, for t >= 3, is

    X[t] = pi(X[t-3]) with probability approximately 0.8,
           a diffuse error symbol otherwise.

The first three symbols are approximately independent uniform draws. The inferred permutation, indexed by source symbol 0..15, is

    [2,12,6,15,11,7,8,4,9,5,13,1,14,0,10,3].

Its cycles are (0 2 6 8 9 5 7 4 11 1 12 14 10 13) and (3 15). Thus positions in each residue class modulo three form a shared first-order noisy substitution chain. A streaming core needs only a queue of the last three observed symbols; it is not a fitted hidden-state model. Update the queue with the actual observation, even when it violates the favored substitution. Neither symbol arithmetic nor a special latent-state count is assumed.

## Executable probability model
The clean core is a learned 16x16 distribution T[source,next], with its maximum always at pi(source). T alone achieves late-position held-out KL 0.01169 nats on cached data. Learned neural probabilities are not exactly stationary T: their confidence and diffuse errors vary slightly with position and nearby symbols. The supplied predictor retains fixed, interpretable categorical log-odds corrections, not neural layers:

    logits[y] = log T[source,y] + A[source,y] + B[position,y]
                + D[source,position,y]
                + sum_l C_l[history[-l],y]
                + sum_l E_l[source,history[-l],y].

Here source = history[-3], position = min(length,23)-3; C uses lags {1,2,4,5,6,7,9}, E uses {1,5,7}. Terms requiring unavailable history are zero. Softmax normalizes the 16 logits. All interaction tensors are centered; their marginal effects are absorbed into the corresponding source, position, or lag terms without changing predictions. The 20,048 fitted coefficients are a separate empirical calibration of neural imperfections, not a claim that the generator needs these interactions. Short prefixes use a fixed start vector, a last-symbol table after one symbol, and two additive categorical log-odds tables after two symbols. No original neural weights, activations, attention, MLPs, or runtime queries are used by this executable.

## Prior knowledge and uncertainty
The only prior knowledge used was standard probability, finite-memory processes, categorical regression, and the declared neural execution rules. No generating family, permutation, delay, state count, or intended error law was known in advance. The data identify the favored lag-three permutation extremely strongly, but do not uniquely identify a physical generator. A high-order Markov table or redundant hidden-state realization can represent the same observations. Three independent chains and exactly uniform errors are parsimonious idealizations, not proven conditional-independence claims about every neural probability. Noise around 0.8 is approximate; the evidence does not resolve whether errors exclude or can accidentally redraw the favored symbol. Smaller residual dependencies and position biases are measured and calibrated rather than silently dismissed.

For histories longer than the 23-symbol neural prefix, retain the same local lags and freeze the position calibration at its final measured value. This is an explicit stationary-core extrapolation, not neural evidence beyond context. Histories and rows never communicate; there is no online fitting or persistence.

See evidence.md for held-out comparisons, random-context tests, controlled interventions, ablations, and execution accounting.

`mechanism_core.py` is a separate executable of the minimal approximate generative law (uniform start; 0.8 favored substitution, 0.2 uniform among the other fifteen symbols), including a sampler. `predictor.py` is the higher-fidelity fixed calibrated version. Their distinction makes the structural claim independent of nuisance-regression accuracy.
