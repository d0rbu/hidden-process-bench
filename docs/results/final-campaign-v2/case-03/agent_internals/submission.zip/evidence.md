# Evidence log
Cached data: 128 independent length-24 symbol rows and aligned neural probability vectors. Fit split: first 96 rows; validation: final 32 rows. All 2688 positions with at least 3 predecessors have neural argmax pi(third-last symbol). Empirical symbol generation follows that recurrence at 79.72% of those positions. A last-symbol table gives validation KL 1.5449 nats; the lag-three table gives 0.01169 nats (late positions). Uniform 80% signal plus 20% diffuse noise gives 0.02164 nats.

Independent offline probes: 192 uniformly random 23-symbol histories, all prediction positions checked. The lag-three permutation explains every one of 4032 eligible argmaxes, not just typical generated sequences. Mean lag-table KL was 0.01297 nats. In controlled final-position sweeps, lag 3 produced 16 distinct argmaxes and max pairwise TV 0.843; each other lag 1..23 left the argmax unchanged. Small nuisance dependencies remain (notably lags 1,5,7, TV up to 0.09 in this background). The permutation decomposes into one 14-cycle and one 2-cycle.

Head/MLP interventions on 96 contexts (32 cached, 64 independent random):
{"kind": "head", "layer": 0, "head": 0, "KL_from_base": 0.007740012800974908, "permutation_accuracy": 1.0, "favored_probability": 0.7534782555542238}
{"kind": "head", "layer": 0, "head": 1, "KL_from_base": 0.005357327130126452, "permutation_accuracy": 1.0, "favored_probability": 0.7591913501239973}
{"kind": "head", "layer": 0, "head": 2, "KL_from_base": 0.009902208625075109, "permutation_accuracy": 1.0, "favored_probability": 0.7471712747702657}
{"kind": "head", "layer": 0, "head": 3, "KL_from_base": 0.012831025409224994, "permutation_accuracy": 1.0, "favored_probability": 0.7411841619493157}
{"kind": "head", "layer": 1, "head": 0, "KL_from_base": 0.005829625828790136, "permutation_accuracy": 1.0, "favored_probability": 0.747647862941711}
{"kind": "head", "layer": 1, "head": 1, "KL_from_base": 0.00456039462790617, "permutation_accuracy": 1.0, "favored_probability": 0.7552211529970713}
{"kind": "head", "layer": 1, "head": 2, "KL_from_base": 0.008629210548396115, "permutation_accuracy": 1.0, "favored_probability": 0.7441398915746698}
{"kind": "head", "layer": 1, "head": 3, "KL_from_base": 0.0032586377398773113, "permutation_accuracy": 1.0, "favored_probability": 0.7612742813094391}
{"kind": "mlp", "layer": 0, "KL_from_base": 0.01479146962751646, "permutation_accuracy": 1.0, "favored_probability": 0.7489853035971018}
{"kind": "mlp", "layer": 1, "KL_from_base": 0.034338394486770354, "permutation_accuracy": 1.0, "favored_probability": 0.6791813261122663}
These interventions diagnose how the neural implementation retrieves the delay; they do not add heads or MLPs to the submitted generator.

Fixed categorical log-odds calibration (20,048 coefficients) was fitted on 1,760 contexts and checked on 608 held-out contexts, late-position KL 0.0035654 nats. This is a nuisance correction to the lag-three rule, not a new generating hypothesis. The JSON executable passed tests including a 70-symbol history. No subprocess access was needed.

Additional untouched stress contexts (constant, period-three, alternating, and noiseless inferred recurrence):
{
  "alternating": {
    "histories": 16,
    "argmax_agreement": 1.0,
    "calibrated_KL": 0.007842919131287263,
    "lag_table_KL": 0.01952141019299794
  },
  "constant": {
    "histories": 16,
    "argmax_agreement": 1.0,
    "calibrated_KL": 0.0066416407466836505,
    "lag_table_KL": 0.009144137153690576
  },
  "noiseless_recurrence": {
    "histories": 32,
    "argmax_agreement": 1.0,
    "calibrated_KL": 0.002700933278514291,
    "lag_table_KL": 0.010811063902153408
  },
  "period_three": {
    "histories": 64,
    "argmax_agreement": 1.0,
    "calibrated_KL": 0.00599029865100443,
    "lag_table_KL": 0.011891488802886771
  }
}
A two-symbol additive short-prefix calibration has held-out KL 1.8740157311326414e-05 nats. It uses only fixed first/second-symbol categorical effects.

The final calibrated predictor is explicitly log(T[source]) plus centered categorical corrections. Reparameterization preserves all held-out probabilities to numerical precision. The pure minimal law is also independently executable in mechanism_core.py. Final interface tests include history lengths 0 through 9, 17, 23, 24, 70, and 257; reordering or removing other rows does not affect a row. No additional neural executions were made.

Observed-token stochasticity check (descriptive, not proof of independence): {"eligible_observed_tokens": 2688, "favored_substitution_count": 2143, "favored_substitution_rate": 0.7972470238095238, "Wilson_95_percent_interval": [0.7816288083532462, 0.812016851855914], "success_correlation_lag_1": 0.035208269937630224, "success_correlation_lag_2": -0.0028872363871681617, "success_correlation_lag_3": -0.006052542199511851, "success_correlation_lag_6": 0.013070301349244823}. The recurrence rate is compatible with approximately 0.8. This does not resolve exact error semantics. Final standalone checks additionally cover 10,000-symbol histories, empty batches, independent row reordering, and the minimal generator sampler. No additional neural execution or fitting was performed.
