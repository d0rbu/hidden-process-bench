"""Uncalibrated structural mechanism; no fitted tables or neural model."""
import json, sys
PERMUTATION=(2,12,6,15,11,7,8,4,9,5,13,1,14,0,10,3)

def next_probabilities(history):
    if len(history)<3:
        return [1.0/16]*16
    # A FIFO of three observed symbols is the only necessary state.
    mode=PERMUTATION[int(history[-3])]
    p=[0.2/15]*16
    p[mode]=0.8
    return p

if __name__=='__main__':
    request=json.load(sys.stdin)
    v=int(request['vocab_size'])
    p=[next_probabilities(h) if v==16 else [1.0/v]*v
       for h in request['histories']]
    print(json.dumps({'probabilities':p}))
