import json, sys
from pathlib import Path
import numpy as np

def softmax(x):
    e=np.exp(x-np.max(x)); return e/e.sum()

def main():
    request=json.load(sys.stdin)
    v=int(request['vocab_size'])
    z=np.load(Path(__file__).with_name('calibration.npz'),allow_pickle=False)
    result=[]
    for history in request['histories']:
        h=[int(a) for a in history]; t=len(h)
        if v!=16 or any(a<0 or a>=16 for a in h):
            result.append([1.0/v]*v); continue
        if t==0:
            p=z['start0']
        elif t==1:
            p=z['start1'][h[0]]
        elif t==2:
            w=z['start2']; p=softmax(w[0]+w[1+h[0]]+w[17+h[1]])
        else:
            # Core: the parent is three steps back, preferred output is its substitution.
            a=h[-3]; mode=int(z['permutation'][a]); position=min(t,23)-3
            logits=z['parent_logits'][a,position].copy()
            for j,lag in enumerate((1,2,5,6)):
                logits+=z['recent'][j,h[-lag] if t>=lag else 16]
            # Small frozen calibration of modal confidence, not a new hidden state.
            correction=z['confidence_position'][a,position]
            correction+=z['confidence_pair'][0,a,h[-1]]
            correction+=z['confidence_pair'][1,a,h[-2]]
            logits[mode]+=correction
            p=softmax(logits)
        result.append((p/p.sum()).tolist())
    print(json.dumps({'probabilities':result},allow_nan=False))

if __name__=='__main__':
    main()
