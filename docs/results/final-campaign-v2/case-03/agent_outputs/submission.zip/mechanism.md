# A noisy three-step substitution channel

## Structural mechanism
Keep a FIFO register of the last three observed tokens. For history length t>=3, let a=x[t-3] and emit f(a) with probability about 0.8; spread the remaining probability diffusely over other symbols. Shift the observed new token into the register. The first three symbols are diffuse seeds. This is an order-three observable-memory process, not a fitted hidden-state network. Under independent seeds and noise, it is equivalently three interleaved first-order substitution chains.

f = [2,12,6,15,11,7,8,4,9,5,13,1,14,0,10,3].

The cycles are (0 2 6 8 9 5 7 4 11 1 12 14 10 13) and (3 15). `core.py` independently executes this mechanism using uniform seeds and probability 0.8 for the preferred symbol. No latent-state count was assumed or estimated.

## Evidence for structure
All 2,688 supplied predictions with a delayed parent have argmax f(x[t-3]), without exception. A retrospective replication selecting among lags 1..12 on 32 rows recovers lag three and the same permutation; it then matches all 2,016 delayed predictions in the other 96 rows. This is internal replication, not a new independent dataset. Best single-symbol lag-one, lag-two and lag-four rules explain only 13.3%, 10.8%, 10.5% on the full data. Lag-six and lag-nine agreement (79.7%, 63.3%) is consistent with repeated noisy substitution rather than additional parents. The first three distributions are diffuse. Supplied tokens agree with the delayed mode 2,143/2,688 times; these tokens might include designed probes, so their frequency is not assumed to be an unbiased noise estimate.

## Fixed neural-probability calibration
`predictor.py` preserves the explicit delayed parent and substitution but calibrates the neural model's imperfect probabilities. Put s=min(t,23)-3. For t>=3 its logits are

L_j = A[a,s,j] + sum_{l in {1,2,5,6}} B[l,x[t-l],j]
      + 1[j=f(a)] * (C[a,s]+P1[a,x[t-1]]+P2[a,x[t-2]]).

Missing lag values use a sentinel; apply softmax to L. A is a categorical parent/position table hierarchically ridge-shrunk toward separate parent and position fields, initialized around the explicit 0.8-modal channel. B are additive token fields. C,P1,P2 are 848 ridge-2 scalar corrections to residual modal log-odds. Startup uses the common empty-prefix vector, 16 length-one responses, and additive length-two logit fields. All arrays are fixed; there is no evaluation-time fitting, cross-row dependence, external data, or neural execution. These calibration dependencies are not asserted to be generator causes.

Whole-row four-fold mean KL(network || candidate) / TV: parent-only 0.01150 / 0.04025; additive calibration 0.00764 / 0.03581; categorical parent-position calibration 0.00482 / 0.02743; final confidence-refined calibration 0.00439 / 0.02569. These are selection-adaptive internal validation results. Fold details, alternatives and execution accounting are in evidence.json.

## Prior, uncertainty and alternatives
Generic categorical finite-memory models, delays, permutations, regularized regression and held-out validation were methodological prior knowledge. No generating family, lag, permutation or state dimension was supplied. The exact modal relation strongly supports delayed substitution but does not uniquely identify the true generator, independent noise, independent initial seeds, or the exact corruption convention. An HMM or another process agreeing on this finite support remains possible. Token-specific tails, absolute-position effects and extra-lag calibration may be neural approximation artifacts. Histories beyond the observed context retain the stationary lag-three core and saturate position calibration at position 23, an untested extrapolation. Only cached observations were used; there were zero neural instances, executions or extra teacher queries.
