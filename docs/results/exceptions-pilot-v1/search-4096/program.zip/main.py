import json, random, sys
r = json.load(sys.stdin)
n = r["task"]["operand_limit"]
history = r["history"]
seen = {tuple(p) for h in history for p in h["queries"]}
if r["remaining_queries"]:
    rng = random.Random(721)
    choices = []
    count = min(r["remaining_queries"], n*n-len(seen))
    while len(choices) < count:
        p = (rng.randrange(n), rng.randrange(n))
        if p not in seen:
            choices.append(p)
            seen.add(p)
    candidates = []
else:
    choices = []
    candidates = [p for h in history for p,y in zip(h["queries"], h["outputs"]) if sum(p) != y][:r["candidate_limit"]]
print(json.dumps({"queries": choices, "candidates": candidates, "resources": {"method": "uniform distinct input search; rank observed disagreements in query order", "offline_forward_calls": 0}}))
