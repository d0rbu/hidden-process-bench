import hashlib
import json
import shutil
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parent.parent
suite = repo / 'outputs/private-mixed-pilot-v2'
assert not (root / 'plan.json').exists(), 'do not overwrite a campaign'
frozen_source = root / 'method-source' / 'hidden_process_bench'
shutil.copytree(repo / 'src/hidden_process_bench', frozen_source, ignore=shutil.ignore_patterns('__pycache__'))
sys.path.insert(0, str(frozen_source.parent))

from hidden_process_bench.agent_client import restricted_catalog
from hidden_process_bench.discovery import score_process
from hidden_process_bench.experiment import write_json
from hidden_process_bench.research_agent import AgentBudget, run_agent
from hidden_process_bench.submissions import FrozenSubmission, file_manifest, verify_submission

import numpy as np

binary = Path('/home/d0rb/.npm/_npx/bfd05e0424263c63/node_modules/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl/bin/codex')
catalog = root / 'catalog.json'
write_json(catalog, restricted_catalog(Path('/home/d0rb/.codex/models-ultrafast-0.159.2.json'), 'gpt-6.1-sol'))
reports = [(p, json.loads(p.read_text())) for p in sorted((suite / 'private').glob('*/training/report.json'))]
ids = [p.parent.parent.name for p, report in reports if report['checkpoint_qualified']]
assert len(ids) == 5
roster = []
for case in ids:
    packets = {}
    for access in ('outputs', 'internals'):
        challenge = suite / 'public' / case / access
        packets[access] = file_manifest(challenge, max_bytes=64000000)
        roster.append({'id': case, 'access': access, 'files': packets[access]})
    with np.load(suite / 'public' / case / 'outputs/observations.npz') as left:
        with np.load(suite / 'public' / case / 'internals/observations.npz') as right:
            for key in ('tokens', 'probabilities'):
                assert np.array_equal(left[key], right[key]), 'paired observations differ'
budget = AgentBudget()
write_json(root / 'plan.json', {
    'development_only': True, 'final_campaign': False,
    'agent_protocol_version': 2,
    'roster': roster, 'budget': asdict(budget),
    'method_sha256': file_manifest(frozen_source),
    'source_commit': 'ff7074efdf2ffba544707304f2a52978d07f4cb4',
    'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
    'catalog_sha256': hashlib.sha256(catalog.read_bytes()).hexdigest(),
    'model': 'gpt-6.1-sol', 'effort': 'xhigh', 'parallel_trials': 2,
    'all_submissions_before_any_private_score': True, 'private_feedback': False,
    'source_immutable_and_imported_from_run_snapshot': True,
    'paired_observations_byte_equal': True,
    'note': 'Entire ten-trial roster declared in advance. Fresh contexts with no v1 hypotheses, source truth or scores. Separate protocol version; no selective rescue of timed-out v1 trials.',
})

def trial(row):
    out = root / row['id'] / row['access']
    frozen = run_agent(suite / 'public' / row['id'] / row['access'], binary, catalog, out, budget=budget)
    if frozen is not None:
        verify_submission(frozen)
    result = json.loads((out / 'trial.json').read_text())
    return {'id': row['id'], 'access': row['access'], 'receipt_sha256': None if frozen is None else frozen.receipt_sha256, 'trial': result}

results = []
with ThreadPoolExecutor(max_workers=2) as executor:
    futures = [executor.submit(trial, row) for row in roster]
    for future in as_completed(futures):
        result = future.result()
        results.append(result)
        write_json(root / 'progress.json', {'trials': results})
        print(json.dumps({k: v for k, v in result.items() if k != 'trial'}), flush=True)
write_json(root / 'registration.json', {'trials': results, 'all_ten_finished_before_private_scoring': True})
write_json(root / 'scoring-plan.json', {'registration_sha256': hashlib.sha256((root / 'registration.json').read_bytes()).hexdigest(), 'heldout_sequences': 128, 'splits': ['heldout', 'long'], 'private_feedback_to_methods': False})
scores = []
for row in sorted(results, key=lambda x: (x['id'], x['access'])):
    private = suite / 'private' / row['id']
    result = {**row, 'family': json.loads((private / 'process.json').read_text())['family']}
    if row['receipt_sha256'] is not None:
        out = root / row['id'] / row['access']
        frozen = FrozenSubmission(out / 'submission', row['receipt_sha256'])
        verify_submission(frozen)
        for split in ('heldout', 'long'):
            with np.load(private / 'training' / (split + '.npz'), allow_pickle=False) as data:
                result[split] = score_process(frozen, data['tokens'], data['oracle'], data.get('teacher'), out / ('score-' + split))
                if result[split]['status'] == 'scored':
                    with np.load(out / ('score-' + split) / 'predictions.npz') as predictions:
                        result[split + '_max_total_variation'] = float((np.abs(predictions['probabilities'] - data['oracle']).sum(axis=-1) / 2).max())
    scores.append(result)
    write_json(root / 'score-progress.json', {'cases': scores})
write_json(root / 'report.json', {'development_only': True, 'agent_protocol_version': 2, 'all_submissions_before_any_private_scoring': True, 'cases': scores, 'independent_structure_recovery': None, 'causal_recovery': None})
