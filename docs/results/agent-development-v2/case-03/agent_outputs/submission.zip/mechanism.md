# Persistent-source categorical filtering

## Executable mechanism
Choose a sequence-level source, then evolve a small hidden Markov chain within that source. Four approximate source classes contain 4, 5, 4 and 5 internal states. Tokens are categorical; their numerical ordering is unused. The account has 18 emission rows, 82 allowed transition entries and an initial state-weight vector: 351 free stationary-filter parameters. It is not a transcription of the neural architecture.

For emission matrix E, transition matrix A and state belief b, observing token v gives:

    posterior[k] = b[k]*E[k,v] / sum_i b[i]*E[i,v]
    b_next[j] = sum_k posterior[k]*A[k,j]
    prediction[v] = sum_k b[k]*E[k,v]

A is exactly block diagonal: source identity stays fixed while internal states switch. Parameters are in `model.json`. `predictor.py` implements this recurrence in log space using only the Python standard library. It processes the entire history without truncation, request-time fitting, cached-history lookup, or communication between rows.

### Initial boundary
All 128 cached BOS distributions are identical. Their vector p0 is returned exactly for an empty history. A coherent generative boundary is obtained by writing pi for the stored reference weights and q0=pi E, and defining

    P(initial_state=k, first_token=v) = pi[k]*E[k,v]*p0[v]/q0[v].

This normalized joint has first-token marginal p0. Conditional on the observed first token, its common marginal tilt cancels: the state posterior is proportional to pi[k]*E[k,v]. All later filtering therefore uses the ordinary recurrence initialized with the stored reference weights. Only this initial boundary is time dependent.

## Inferred organization
Labels are arbitrary, not semantic ground truth. Token summaries use reference initial weights, not a claimed stationary distribution.

| Source | Internal states | Initial source mass | Top reference tokens |
|---|---|---|---|
| 0 | 0,1,2,3 | 0.185 | 0,4,2,7,10 |
| 1 | 4,5,6,7,8 | 0.302 | 4,8,2,14,3 |
| 2 | 9,10,11,12 | 0.217 | 0,10,14,8,9 |
| 3 | 13,14,15,16,17 | 0.296 | 7,8,0,6,4 |

## Evidence and complexity choice
Only the supplied 128 length-24 histories and their 3072 aligned teacher distributions were used. Parameters were fitted to teacher cross-entropy using exact recurrent gradients, checked by finite differences. Histories 0-95 were used for fitting and 96-127 for model comparison. Scores below are mean KL(teacher || candidate), in nats.

* A last-token chain scored 0.1244 on nonempty histories. Accumulated log counts scored 0.0833, and several decaying count traces scored 0.0623. Persistent evidence matters, but simple count reinforcement is insufficient.
* Unrestricted HMMs with 4/8/16/24 states scored approximately 0.0590/0.0236/0.0170/0.0121. Increasing to 32-64 states improved training loss but not held-out agreement.
* The fitted 24-state transition matrix had eigenvalues near 1: 1, .9991, .9948, .9887, .9587. Graph clustering exposed four broad almost-invariant components, with a further nearly isolated background state. Enforcing four source blocks changed KL only from 0.01213 to 0.01237.
* Merging states within those blocks and refitting gave 20/18/16/12-state scores 0.01238/0.01258/0.01356/0.01847. Eighteen states retained nearly the accuracy of 20-24 at smaller complexity; 12 lost appreciable fidelity. This is a useful approximation resolution, not an identified true latent count.
* Observable copy/repetition effects, source-specific observable Markov chains, and tempered/leaky likelihood updates were tested. None justified replacing this account. Full comparisons, including paired whole-history uncertainty, are in `evidence.json`.

The final boundary-calibrated 18-state validation KL was 0.012410, before the final fit. After structure selection, all 128 supplied histories were used for 800 fixed additional gradient updates. The final all-data loss is reported only as training loss. Frozen prediction never refits or compares an input against training rows.

## Prior knowledge, assumptions and alternatives
Prior knowledge was generic: finite-state stochastic processes, Bayesian filtering, reinforcement/count models, regression and spectral graph clustering are possible representations. Neither a generating family nor a source/state count was supplied. HMMs were a tested hypothesis, not task-provided knowledge. No token semantics or numerical token geometry was assumed.

The strongest structural conclusion is persistent mixture-like context plus within-context dynamics. Exact source permanence is less certain: a tiny between-source escape probability improved one comparison by about 0.00025 KL. Very slow source switching remains compatible with these short histories. Four versus five source classes is ambiguous because of a nearly isolated background state. State splitting, merging and label permutations are non-identifiable; states are not claimed to be recovered physical entities. A larger ordinary HMM or continuous-state Bayesian mechanism could approximate the same predictions.

The same 32 validation histories were reused for many comparisons, so small differences and standard errors are descriptive rather than an untouched test. The teacher is itself approximate; agreement does not prove the original generator. No interventions, weights or activation traces were available. Stationarity and persistent sources beyond length 24 are unverified extrapolations, although the executable handles long histories stably.
