import json,sys,math
from pathlib import Path

def load():
    data=json.loads(Path(__file__).with_name("model.json").read_text())
    emission=data["emission"]
    transition=data["transition"]
    count=len(emission)
    initial=tuple(math.log(p) for p in data["initial"])
    log_emission=tuple(tuple(math.log(p) for p in row) for row in emission)
    incoming=tuple(tuple((i,math.log(transition[i][j])) for i in range(count) if transition[i][j]>0) for j in range(count))
    return initial,emission,log_emission,incoming,tuple(data["bos"])

def predict(history,parameters):
    initial,emission,log_emission,incoming,bos=parameters
    if not history:
        return list(bos)
    count=len(initial)
    vocabulary=len(bos)
    logb=list(initial)
    for token in history:
        if not isinstance(token,int) or not 0<=token<vocabulary:
            raise ValueError("Expected categorical tokens 0 through 15")
        u=[logb[k]+log_emission[k][token] for k in range(count)]
        following=[]
        for edges in incoming:
            scores=[u[i]+logp for i,logp in edges]
            maximum=max(scores)
            following.append(maximum+math.log(math.fsum(math.exp(s-maximum) for s in scores)))
        maximum=max(following)
        logb=[s-maximum for s in following]
    weights=[math.exp(s) for s in logb]
    total=math.fsum(weights)
    weights=[p/total for p in weights]
    q=[math.fsum(weights[k]*emission[k][v] for k in range(count)) for v in range(vocabulary)]
    total=math.fsum(q)
    return [p/total for p in q]

def main():
    request=json.load(sys.stdin)
    parameters=load()
    if request["vocab_size"]!=len(parameters[-1]):
        raise ValueError("This mechanism has vocabulary size 16")
    probabilities=[predict(history,parameters) for history in request["histories"]]
    json.dump({"probabilities":probabilities},sys.stdout,allow_nan=False)

if __name__=="__main__":
    main()
