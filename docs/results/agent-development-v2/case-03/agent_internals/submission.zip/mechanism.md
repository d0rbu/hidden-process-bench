# A hierarchical predictive-state filter

## Prior knowledge and claim
I used generic knowledge of causal stochastic processes, Bayesian filtering, mixtures, Markov models and low-rank regression. No task-specific generating family, regime count, or latent dimension was supplied or presumed. This is an executable approximation to the neural predictions, not a uniquely identified original generator.

## Structure and executable rules
There are four persistent sequence regimes, each with four evolving local states. The belief b therefore has 16 components indexed by (regime, local state). A is exactly block diagonal, with four stochastic 4x4 blocks. E is a stochastic emission table. pi initializes the belief. F is a positive, row-normalized table of recognition likelihoods, learned separately from E. C supplies an explicit last-token-dependent logit correction.

For every observed token u, in order:

    posterior = b * F[:, u]
    posterior /= sum(posterior)
    b = posterior @ A

After a nonempty history h:

    q = b @ E
    prediction = softmax(log(q) + C[h[-1]])

An empty history returns the single observed BOS distribution. State resets to pi for every row and request. All history is processed, without truncation. Parameters are fixed; the runtime uses only the Python standard library and packaged parameters.json, with no neural execution, fitting, persistence, or communication across rows.

The simpler generative interpretation is: choose one regime for the sequence, emit from its local state, and transition within that regime. The submitted predictor is a calibrated recognition filter for this structure: F need not equal E, and C corrects the observation distribution. It is consequently NOT claimed to be the exact Bayesian posterior of that generative HMM. Its 798-parameter upper bound includes emissions, local dynamics, recognition, local calibration and BOS. Within-regime dynamics capture order-sensitive local evidence; regime posterior mass supplies persistent sequence-level memory. State labels have no identified semantic meaning.

## Evidence and complexity decisions
Splits are by complete sequence. Cached observations were split 96/32. Additional histories were sampled from an already fitted mechanism, uniformly, from small alphabets, and as constant runs followed by random suffixes. Their neural predictions were computed offline from supplied weights using the declared helper. Synthetic splits were fixed before fitting those predictions. The final fit uses 1184 sequences and the reported comparison uses 352 held-out sequences. These held-out sets guided architecture selection and are not untouched final statistical tests.

Cached held-out KL baselines: first-order observed Markov 0.1193; static iid EM mixture 0.0835; token-count/recency log-linear model 0.0641. A static Markov mixture fitted directly to teacher probabilities reached 0.02495. An unrestricted 24-state HMM reached 0.01478. Four regimes with four local states reached 0.01298 before augmentation. With augmented evidence, three/four/five regimes, each with four states, gave 0.01913/0.01150/0.01146: the fifth regime offered negligible benefit. Four regimes with only three local states were worse (0.01571). Recognition calibration and local output correction were tested separately from increasing state count. Adding a fifth local state improved calibrated cached KL by only about 0.00043 while adding 156 parameters; four local states were retained.

The final cached validation KL is 0.009276. New held-out mechanism-sampled histories give 0.008812; new uniform histories give 0.018887; runs give 0.012374; small-alphabet histories give 0.012915. Exact scores, alternative-family searches and parameter shapes are in evidence.json. BOS is calibrated exactly from its identical observed distribution.

Controlled interventions support order-sensitive and persistent evidence. Eight histories with identical unigram and bigram counts and final token still produced differing neural distributions, rejecting exact count sufficiency. With 20 identical recent tokens, changing the earlier three tokens changed teacher output by mean total variation 0.1735; a short suffix alone is insufficient. The mechanism's corresponding value is 0.2227. All suffix lengths and quantitative counterfactual discrepancies are recorded, including cases of imperfect agreement. These probes were not fitting rows.

No-refit perturbations remove the local correction, tie recognition to emissions, freeze individual states, reset local states within a regime, or reset the entire belief. Their errors document dependencies of this fitted representation. They are not clean causal identifications: calibration and emissions can compensate for each other. A separate common-only output correction controls for the global calibration component when examining direct last-token dependence.

## Uncertainties and alternatives
Four regimes and four local states are a parsimonious working representation, not proven true counts. Very slow regime switching, a continuous latent topic, a differently factored source, or a larger HMM can explain some of the same observations. Static iid/Markov mixtures, direct autoregressive switching emissions, unrestricted HMMs, and tied/tempered recognition filters were explicitly compared. Low-dimensional probability geometry and slow transition modes motivated a hierarchy, but do not identify one uniquely.

Nonconvex optimization used limited starts, so family comparisons are not exhaustive. Baselines do not all share the same fitting objective. Synthetic histories favor the mechanism that sampled them; original, uniform, run and small-alphabet checks partially counter this bias. Neural approximation artifacts may account for recognition/output corrections rather than extra generating states. State permutations and alternative predictive-state parameterizations remain unidentifiable.

Long-history filtering is a time-homogeneous extrapolation, not empirically established beyond the neural context. Length-2048 tests establish numerical validity only, not predictive agreement there. Repeated-token interventions are deliberately atypical. This submission explains predictive dependencies and offers a compact executable hypothesis, rather than asserting recovery of latent semantics.

## Files and accounting
predictor.py and parameters.json suffice for inference; no original neural arrays or observations are required. evidence.json records searches, complete-sequence splits, counterfactuals, no-refit ablations and actual fresh-process protocol tests. submission.json records all helper instances, execution totals and fitting work. No neural operations were reimplemented.
