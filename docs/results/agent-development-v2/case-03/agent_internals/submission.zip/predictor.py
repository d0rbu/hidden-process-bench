import sys,json,math
from pathlib import Path
with Path(__file__).with_name("parameters.json").open() as stream:
    P=json.load(stream)
E,A,PI,F,C,INITIAL=[P[k] for k in ("E","A","pi","F","C","initial")]
def predict(history):
    if len(history)==0:
        return INITIAL[:]
    belief=PI[:]
    last=0
    for raw in history:
        token=int(raw)
        if token<0 or token>=16:
            raise ValueError("tokens must lie in 0..15")
        posterior=[belief[k]*F[k][token] for k in range(16)]
        denominator=sum(posterior)
        posterior=[v/denominator for v in posterior]
        belief=[sum(posterior[k]*A[k][j] for k in range(16)) for j in range(16)]
        last=token
    q=[sum(belief[k]*E[k][j] for k in range(16)) for j in range(16)]
    logits=[math.log(max(q[j],1e-300))+C[last][j] for j in range(16)]
    maximum=max(logits)
    probabilities=[math.exp(v-maximum) for v in logits]
    total=sum(probabilities)
    return [v/total for v in probabilities]
if __name__=="__main__":
    request=json.load(sys.stdin)
    if int(request["vocab_size"])!=16:
        raise ValueError("this source has a 16-symbol vocabulary")
    print(json.dumps({"probabilities":[predict(h) for h in request["histories"]]},allow_nan=False))
