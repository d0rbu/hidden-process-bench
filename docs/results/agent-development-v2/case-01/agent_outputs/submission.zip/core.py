"""Uncalibrated structural idealization, not the neural calibration layer."""
PERMUTATION=(14,12,7,1,5,11,3,10,15,8,13,2,6,0,4,9)

def next_probabilities(history):
    if len(history)<3:return [1/16]*16
    p=[0.02]*16
    p[PERMUTATION[history[-3]]]=0.70
    return p
