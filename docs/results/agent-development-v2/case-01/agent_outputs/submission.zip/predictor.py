"""Noisy three-step permutation; frozen explicit probability calibration."""
import json,math,sys
from pathlib import Path

def softmax(v):
    m=max(v); q=[math.exp(x-m) for x in v]; s=sum(q)
    return [x/s for x in q]

def normalize(q):
    s=sum(q)
    return [v/s for v in q]

def predict(h,p):
    n=len(h)
    if n==0: return normalize(p['initial'])
    if n==1: return normalize(p['early1'][h[0]])
    if n==2:
        e=p['early2']; inds=[0,1+h[0],17+h[1]]
        return softmax([sum(e[i][k] for i in inds) for k in range(16)])
    a,b,c=h[-3:]; mode=p['permutation'][a]
    positions=[n-3] if n<=23 else list(range(21))
    z=p['confidence_base']+p['confidence_previous2'][b]+p['confidence_previous1'][c]
    z+=sum(p['confidence_source_position'][a][j] for j in positions)/len(positions)
    mass=1/(1+math.exp(-z))
    inds=[0,1+a,17+b,33+c]
    for lag,offset in [(4,70),(5,87),(6,104)]:
        inds.append(offset+(h[-lag] if n>=lag else 16))
    pos=p['offmode_position_basis'];basis=p['offmode_source_basis'][a]
    factors=[sum(v[j] for j in positions)/len(positions) for v in pos]
    off=p['offmode_additive']
    logits=[sum(off[i][k] for i in inds)+sum(off[49+j][k] for j in positions)/len(positions)+sum(v*f for v,f in zip(basis[k],factors)) for k in range(16)]
    others=[k for k in range(16) if k!=mode]
    noise=softmax([logits[k] for k in others]);ans=[0.0]*16
    ans[mode]=mass
    for k,v in zip(others,noise):ans[k]=(1-mass)*v
    return normalize(ans)

def main():
    x=json.load(sys.stdin)
    if x['vocab_size']!=16:raise ValueError('Expected the fitted 16-symbol alphabet')
    p=json.loads(Path(__file__).with_name('parameters.json').read_text())
    json.dump({'probabilities':[predict(h,p) for h in x['histories']]},sys.stdout,allow_nan=False)

if __name__=='__main__':main()
