"""Frozen delayed-substitution source with fixed categorical calibration."""
import json,sys
from pathlib import Path
import numpy as np
D=np.load(Path(__file__).with_name('parameters.npz'),allow_pickle=False)
def softmax(z):
 p=np.exp(z-np.max(z));return p/p.sum()
def predict(history):
 h=history[-23:];t=len(h)
 if t==0:return D['prior'].copy()
 if t==1:return D['one'][h[0]].copy()
 if t==2:return softmax(D['init_intercept']+D['init_first'][h[0]]+D['init_second'][h[1]])
 s,b,c=h[-3:];j=t-3;target=int(D['mapping'][s])
 # Backbone: probability .70 for f(s), .30/15 for every other symbol.
 logits=np.zeros(16);logits[target]=float(D['signal_logit'])
 # Fixed nuisance corrections to the source channel; no fitting at inference.
 logits+=D['channel_residual'][s]+D['p'][j]+D['l'][c]+D['b'][b]+D['cp'][j*16+s]
 confidence=float(D['confidence_c'][s,0]+D['confidence_p'][j,0]+D['confidence_l'][c,0]+D['confidence_b'][b,0]+D['confidence_cl'][s*16+c,0])
 if t>3:
  counts=np.bincount(h[:-3],minlength=16)/(t-3)
  logits+=counts@D['old']
  confidence+=float((counts@D['confidence_old'])[0])
 logits[target]+=confidence
 return softmax(logits)
def main():
 request=json.load(sys.stdin)
 if request['vocab_size']!=16:raise ValueError('The inferred source has vocabulary size 16')
 print(json.dumps({'probabilities':[predict(h).tolist() for h in request['histories']]}))
if __name__=='__main__':main()
