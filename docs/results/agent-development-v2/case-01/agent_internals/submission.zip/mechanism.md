# Mechanism: a noisy, three-step delayed substitution

Maintain a FIFO q=(a,b,c) of the last three observed tokens. After initialization, the dominant next symbol is f(a), where

`f = [14,12,7,1,5,11,3,10,15,8,13,2,6,0,4,9]`.

Emit from a categorical channel concentrated on f(a), then update q <- (b,c,new observation). Equivalently these are three interleaved first-order chains, one for each time residue modulo three. This is observable memory, not an asserted hidden-state count. A flat-state implementation could have 16^3 register configurations, but three cells are the compact representation. f has cycles (0 14 4 5 11 2 7 10 13), (1 12 6 3), (8 15 9).

A parsimonious source law assigns about 0.70 to f(a) and spreads remaining mass over other symbols; the first three emissions are broad seeds. See source_mechanism.json. Neural predictions have mild nonuniform errors and context/position-dependent confidence, so this source law is not claimed to reproduce the network exactly.

## Frozen predictive implementation

The executable uses a categorical logit channel indexed by a, plus fixed calibration terms for prediction position, b, c, source-by-position interaction, and older-token frequencies. A small scalar confidence correction changes only the logit of f(a), using fixed source/recent-symbol terms. The latter approximate small neural artifacts; they do not overturn the dominant delayed substitution or establish extra dependencies in the original data source. The first three positions use a separate broad initialization channel. All tables are learned offline, not from request histories. There are no copied transformer blocks, embeddings, attention, MLPs or neural weights.

## Evidence and alternatives

All 2688 cached predictions with at least three observations obey the dominant mapping exactly. IID, first-lag and two-lag additive alternatives have heldout KL about 1.18 nats; adding lag three reduces this to 0.00979. A stationary 16-row categorical channel alone has KL 0.01223. Controlled changes at lag three alter predictions by mean L1 1.401, versus 0.073 for the most recent observation and <=0.022 for other tested lags. Each altered history obeys the corresponding mapping. The law also holds at every eligible position in 512 uniform and 512 newly simulated source-like histories. Individual neural head/MLP ablations preserve the argmax law in the tested batch, so this is not evidence for a unique module-to-state correspondence. Numerical details and calibration comparisons are in evidence.json.

## Prior knowledge, uncertainty, and extrapolation

Prior knowledge used: categorical distributions, Markov/finite-memory models, permutations, conditional logit regression, ridge regularization and low-rank approximation. No generating family, token semantics, hidden-state dimension, or task-external information was assumed. The lag and permutation were selected from the supplied evidence, not specified in advance.

A higher-order process can be observationally equivalent on finite data. Uniform noise and independent seeding are parsimonious approximations; finite samples cannot prove them. Neural position effects and weak recent/older-token effects are measurable, but may be approximation error rather than source structure. The alternative of three independently evolving chains is just another factorization of the same observable delayed channel, not additional inferred latent variables. For histories longer than neural context, preserve the third-last-token law, saturate positional calibration at length 23, and summarize only the last 20 older visible symbols. This extrapolation is a declared convention, not teacher-verified behavior beyond context.

The source-only executable source_predictor.py gives the core law in 13 lines. The designated predictor adds frozen calibration to that explicit backbone. Selected calibration uses 6736 logit coefficients plus 341 scalar-confidence coefficients and a small initialization channel. The final fixed-structure refit uses 1152 discovery sequences, after heldout structural selection.

A final audit used 512 fresh discovery histories after freezing all coefficients, including constant and periodic stress cases. It did not trigger any refitting. See evidence.json for separate uniform, source-like and stress diagnostics; all new helper executions are explicitly counted.
