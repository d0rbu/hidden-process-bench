import json,sys
F=[14,12,7,1,5,11,3,10,15,8,13,2,6,0,4,9]
def predict(h):
 p=[1/16]*16
 if len(h)>=3:
  p=[.30/15]*16;p[F[h[-3]]]=.70
 return p
if __name__=='__main__':
 x=json.load(sys.stdin);print(json.dumps({'probabilities':[predict(h) for h in x['histories']]}))
