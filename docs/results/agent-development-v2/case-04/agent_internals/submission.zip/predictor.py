import json,sys
from pathlib import Path
z=json.loads(Path(__file__).with_name('parameters.json').read_text())
E,F,A,G,pi=(z[k] for k in ('E','F','A','G','pi'))
K=len(pi)
def predict(history):
    b=pi[:]
    for x in history:
        if not isinstance(x,int) or not 0<=x<16:
            raise ValueError('invalid categorical token')
        u=[b[i]*F[i][x] for i in range(K)]
        v=[G[j][x]*sum(u[i]*A[i][j] for i in range(K)) for j in range(K)]
        s=sum(v)
        b=[v[j]/s for j in range(K)]
    p=[sum(b[i]*E[i][x] for i in range(K)) for x in range(16)]
    s=sum(p)
    return [x/s for x in p]
if __name__=='__main__':
    request=json.load(sys.stdin)
    if request['vocab_size']!=16:
        raise ValueError('expected vocabulary 16')
    print(json.dumps({'probabilities':[predict(h) for h in request['histories']]}))
