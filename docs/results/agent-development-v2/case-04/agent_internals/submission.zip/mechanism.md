# Compact account: normalized categorical evidence accumulation

## Executable mechanism
Memory is an eight-coordinate probability vector b, initialized to pi. For each observed categorical symbol x:

    u_i = b_i F[i,x]
    v_j = G[j,x] sum_i u_i A[i,j]
    b_j = v_j / sum_k v_k

The next-symbol distribution is p(x)=sum_i b_i E[i,x]. E, F, G and A are fixed row-stochastic matrices. Equivalently, each symbol applies the positive operator M[x]=diag(F[:,x]) A diag(G[:,x]), followed by normalization. F supplies evidence about the previous regime, A mixes regimes, and G supplies evidence about the destination regime. The continuous memory has seven simplex coordinates. The factorization stores 456 scalars; it is not a transformer or a copied neural layer.

This also specifies an executable autoregressive generator: sample x from bE, then apply the update. Because readout E is learned separately from update evidence F and G, it is not asserted to be an exactly consistent discrete HMM. The eight coordinates describe an economical inference realization, not eight proven physical source states. Parameters are fixed; every row starts afresh. There is no fitting, cross-row communication or persistent state at prediction time.

## Why this structure and size?
Cached output PCA places 99.55% of variation in five dimensions, suggesting roughly six dominant emission regimes. Independent-probe convex-mixture KL drops from 0.00757 at five components to 0.00223 at six; seven/eight yield smaller further improvements (0.00174/0.00141). Thus six is a useful explanatory core, not an exact dimensional identification.

A first-order model has cached mean KL 0.156. Initial held-out tied-HMM KL for 3/4/5/6/7/8 states is 0.09388/0.04111/0.01946/0.01385/0.01398/0.01389. A six-coordinate evidence filter exhibits two weakly communicating triples, {0,2,5} and {1,3,4}, with cross-group row mass at most 0.00262 and an eigenvalue near 0.998. This supports a slow global mode plus faster within-mode changes, but does not prove permanently disconnected modes. Shared-emission duration substates improve fit slightly, indicating that mixture rank need not equal dynamical complexity.

Final selection used 736 fitting histories and 256 held-out histories, including cached, mechanism-generated, uniform, block-switch and teacher-sampled sequences. Five/six/eight-coordinate two-sided filters attain validation KL 0.02427/0.01850/0.01696. The selected eight-coordinate factorization is smaller than the six-coordinate unrestricted positive-operator model (456 versus 678 stored scalars), and improves its validation KL from 0.01775 to 0.01696.

On 192 fresh, unfitted histories the selected filter gives mean KL 0.01773: teacher-sampled 0.01112, mechanism-generated 0.00959, uniform 0.04732, block-switch 0.01765. The six-coordinate unrestricted operator gives 0.01917 overall. Several candidates were compared on this fresh check, so it is selection evidence, not an untouched test. All KL values use neural distributions as the first argument. Search details and rejected alternatives are in evidence.json.

## Prior knowledge, alternatives and uncertainty
Prior knowledge was generic categorical chains, HMMs, Bayesian filtering, positive linear systems and matrix factorization; no task-specific generator, family or latent count was supplied. Tested alternatives include finite windows, static mixtures with forgetting, tied HMMs, separate evidence/readout filters, generative transition-edge emissions, larger unrestricted operators and shared-emission duration substates. Broader static-mixture alternatives give KL about 0.058. Finite-window fits improve steadily with longer windows, supporting accumulated evidence rather than only the last token.

Six-filter beliefs are linearly decodable from held-out neural activations (R2=0.959), which is correlational support rather than unique identification. Head ablations change outputs by KL 0.0013--0.0068; MLP ablations give 0.0205/0.0330. No head is identified with a particular latent regime. Neither activations nor neural weights occur in the predictor.

Uncertainties include non-unique latent coordinates and operator scaling, neural approximation error, duration effects, and imperfect behavior on deliberately unlikely histories. The positive filter is a compact predictive account, not recovery of a uniquely identifiable original source. Stationarity is assumed. Histories beyond neural context use the same recurrence without truncation; that extrapolation is not verified against the context-limited teacher. Validation was repeatedly inspected during model selection. No evaluation histories are fitted or compared by the executable.
