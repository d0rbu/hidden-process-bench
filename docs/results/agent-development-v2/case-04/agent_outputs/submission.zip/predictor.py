import json,sys
from pathlib import Path
P=json.loads(Path(__file__).with_name("parameters.json").read_text())
PI,A,L,R,TAU=(P[k] for k in ("pi","A","L","R","tau"))
K=len(PI);V=len(R[0])
def predict(history):
 if not history:return P["start"][:]
 b=PI[:]
 for token in history:
  if not isinstance(token,int) or not 0<=token<V:raise ValueError("Invalid token")
  u=[b[i]*L[i][token] for i in range(K)]
  s=sum(u);u=[v/s for v in u]
  b=[sum(u[i]*A[i][j] for i in range(K)) for j in range(K)]
 q=[sum(b[i]*R[i][a] for i in range(K)) for a in range(V)]
 q=[max(v,1e-300)**TAU for v in q];s=sum(q)
 return [v/s for v in q]
def main():
 d=json.load(sys.stdin)
 if int(d["vocab_size"])!=V:raise ValueError("Expected vocabulary size 16")
 print(json.dumps({"probabilities":[predict(h) for h in d["histories"]]}))
if __name__=="__main__":main()
