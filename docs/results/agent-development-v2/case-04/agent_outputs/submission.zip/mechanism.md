# Six-regime calibrated categorical filter

## Claim and executable mechanism
The smallest consistently competitive account found is a belief over six predictive regimes, with persistent, nearly block-structured transitions. The submitted predictor is a calibrated Bayesian-style filter, not a copy of the neural network and not a claim to have uniquely recovered its original generator.

Let b be a six-entry probability row vector, initially pi. For each observed token a:

    u_i = b_i L[i,a] / sum_j b_j L[j,a]
    b   = u A

For the next token, compute:

    r_a = sum_i b_i R[i,a]
    q_a = r_a ** tau / sum_c r_c ** tau

All entries of pi, A, L and R are positive and their categorical rows sum to one. The fitted scalar tau is approximately 1.6493. parameters.json contains all constants. The empty history uses the shared cached BOS distribution, normalized once. There is no history lookup, refitting, randomness, cross-row communication, request persistence, or original-model dependency. The implementation uses only Python's standard library. The six-entry belief has five independent coordinates; there are 251 stored scalar values, or 231 nominal free values after row normalizations, including the BOS distribution and scalar calibration.

This recurrence itself defines a sequence-generating mechanism: emit a token from q(b), then update b with that token. With L=R and tau=1 it is an ordinary categorical-emission HMM, using emission-before-transition timing. The fitted L/R separation and output calibration relax that self-consistency to represent the neural predictor's errors or a somewhat richer process. R is therefore an output basis, not asserted to be a literal ground-truth emission table. generative_comparator.json supplies a separately fitted ordinary six-state HMM for structural comparison; the predictor does not read it.

## Evidence and complexity selection
Only the 128 cached length-24 token sequences and their 16-way next-token probabilities were used. Probability geometry shows five dominant centered directions, explaining approximately 99.55% of variance: singular values 10.24, 6.40, 5.12, 3.51, 1.64, followed by a smaller residual tail (.527, .395, ...). A mixture of six categorical basis distributions has at most five independent centered directions. Nonnegative rank-4/5/6 reconstructions have probability RMSE .0191/.00846/.00416. These motivate a search, not a proof of six states.

Initial fitting used 96 complete sequences; the other 32 were held out. Teacher-to-candidate KL (nats per position):

| Mechanism | Held-out KL |
|---|---:|
| Constant distribution fitted on training rows | .33451 |
| Previous-token categorical table, training rows only | .15719 |
| Refitted static six-component mixture (A=identity) | .14283 |
| Ordinary HMM: 4 / 5 / 6 states | .04116 / .01955 / .01386 |
| Ordinary HMM: 7 / 8 states | .01416 / .01424 |
| Six regimes, separate recognition/output tables | .01230 |
| Six regimes plus output calibration | .01166 |
| Seven regimes plus output calibration | .01109 |

Six-state HMM fits from three initializations converge to held-out KL near .01384. Extra states, likelihood tying, posterior tempering, reverse update ordering and independent symbol-conditioned operators were examined. More general 6x6 operators for every symbol offer little benefit over diag(L[:,a]) A, supporting the factorized update. Keeping only the last 1/4/8/16 tokens in the uncalibrated six-regime filter gives .16019/.04979/.02217/.01272, versus .01230 for all available history: this is not merely a last-token process. A fixed mixture is much worse, supporting regime transitions rather than a single static class per sequence.

Two additional randomized 96/32 whole-sequence splits used fresh train-only initializations. Calibrated six/seven-state KL was .01472/.01626 and .01258/.01199. Across these and the original split, means are .01299/.01311. Six is chosen for economy and stability, not because seven is impossible. These adaptively used checks are not an untouched test. Final constants were fitted offline on all 128 observations from three initializations, which converged to essentially the same .01064 in-sample KL. This is a fitting diagnostic, not a generalization score. Analytic training gradients were checked against finite differences. Detailed experiments and numerical execution accounting are in evidence.json.

## Interpretation
Regimes have distinct, overlapping categorical preferences rather than numerical token meanings. The final fitted regimes are summarized below; pure-regime output means calibrating one row of R, not averaging calibrated rows.

| Regime | Highest-probability pure-regime output labels | Self-transition |
|---|---|---:|
| 0 | 14, 13, 9, 15 | 0.931 |
| 1 | 15, 10, 8, 0 | 0.518 |
| 2 | 7, 14, 13, 1 | 0.803 |
| 3 | 1, 5, 2, 7 | 0.670 |
| 4 | 4, 12, 0, 9 | 0.676 |
| 5 | 12, 6, 11, 4 | 0.565 |

The two weakly connected groups are {0,3,4} and {1,2,5}; per-regime cross-group transition probabilities range from about 0.00000 to 0.00989. These are fitted effective dynamics, not directly observed transition frequencies.

 The learned transition topology is persistent and close to two weakly connected groups. Exact block separation worsens initial held-out fit (.01318 versus .01230 without calibration), so the executable retains small cross-group transitions. Overlapping recognition likelihoods maintain uncertainty across regimes. State labels are arbitrary; fitted tables are the definition, not semantic names.

## Prior knowledge, assumptions and uncertainty
Prior knowledge used: generic categorical probability, matrix factorization, Markov processes, Bayesian filtering, gradient optimization, and sequence-level validation. No generating family, latent count, token partition, dynamics or task-specific mechanism was supplied or assumed known. Tokens are unordered categorical labels. The six-regime count and nearly reducible structure were inferred from the cached outputs.

The predictor assumes stationary fixed-parameter recognition and transitions. It is an effective predictive-state account, not proof of six ontological hidden states or unique identifiability. Factorizations, regime permutations and other equivalent representations remain possible. Ordinary HMMs, weak switching between two classes, additional small latent factors, time-dependent inference error, and longer-memory mechanisms remain alternatives. Calibration improves agreement but weakens a literal conditional-independent-emission interpretation. Cached observational agreement alone cannot establish causal necessity or uniquely distinguish neural approximation error from generator complexity.

All available prediction positions have history length 0--23. For longer histories the submitted recurrence continues without truncation; it does not pretend to reproduce unspecified neural sliding-window behavior. This extrapolation is defined and numerically tested, but not validated by supplied probabilities. No new teacher queries, neural ablations or weight-based execution were performed.
