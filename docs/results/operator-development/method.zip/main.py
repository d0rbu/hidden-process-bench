from method.operator_method import main
main()
